# ENCARGO PARA CODEX — ELECTRICISTA EN EL BOLSILLO V6

## OBJETIVO INNEGOCIABLE
Convertir este proyecto Android Studio y su HTML de pruebas en una aplicación eléctrica profesional con un modelo neuronal real y operativo OFFLINE, sin perder ninguna función V5/V6. NO afirmar que funciona si no se ha ejecutado y verificado. El usuario desea que Codex haga las investigaciones, ediciones, compilaciones y pruebas automatizadas, sin pedirle pruebas manuales todavía.

## ESTADO DE PARTIDA (V6.10)
- Hay interfaz HTML, motor de reglas, calculadoras, presupuestos, PDF, historial, idiomas ES/EN/FR, escáner y planos/unifilares. No asumir que cada módulo funciona; auditar uno por uno.
- Existe `app/src/main/java/com/bolsillo/electricista/NeuralElectricalEngine.kt` con integración intentada LiteRT-LM; no hay inferencia neuronal verificada.
- Existe módulo `neuralmodel` para Google Play Asset Delivery, pero `neuralmodel/src/main/assets/` contiene SOLO un TXT de instrucciones: FALTAN PESOS REALES `.litertlm`.
- Se han probado parcialmente funciones JavaScript y casos de respuestas; no hay APK compilada validada ni regresión integral.
- Hubo respuestas erróneas a consultas de seguridad ('humo en cuadro') y explicaciones incompletas de contactores; hay reglas de emergencia añadidas, pero validar rutas Android/HTML.
- El HTML puede usar el motor Java nativo cuando existe el puente; revisar coherencia y fallbacks.
- El usuario quiere botón azul de IA en cabecera Y botón IA en navegación inferior, sin tapar formularios.

## PRIORIDADES POR ORDEN
1. Inventariar código, dependencias, permisos, versiones y puntos de entrada. Registrar fallos reales con rutas y líneas. Mantener copia del estado inicial.
2. Revisar documentación y código abierto OFICIAL de Google LiteRT-LM, Android, llama.cpp o alternativa fiable. Verificar API, versión, arquitectura ARM64, soporte del modelo, licencias y requisitos de RAM. Si LiteRT-LM falla, elegir y justificar un motor compatible probado, no inventar APIs.
3. DESCARGAR pesos REALES y legales de un modelo pequeño de lenguaje (preferencia Qwen3-0.6B cuantizado compatible con el runtime elegido) desde fuente verificable; registrar URL, licencia, tamaño, SHA256 y prueba de integridad. Si el entorno no tiene red, dejar error claro, scripts reproducibles y bloqueo de release; no fingir instalación.
4. Integrar runtime, modelo, carga, descarga o entrega Google Play (Play Asset Delivery), ejecución asíncrona, callbacks, gestión de memoria, timeout, cancelación, estados de error, reintento y fallback seguro. Distinguir APK local de AAB Google Play. Sin envío de preguntas privadas a servicios externos.
5. Unificar motor de respuestas y priorizar seguridad: humo, fuego, chispas, electrocución. Evitar que IA generativa dé procedimientos peligrosos o afirmaciones normativas no verificadas; citar biblioteca REBT cuando proceda. El modelo base NO está especializado en electricidad: integrar recuperación local de conocimiento (RAG) y validación, sin afirmar que está entrenado específicamente.
6. Compilar de verdad con Gradle/Android SDK (`assembleDebug`, `bundleRelease` si es posible); resolver dependencias y errores, repetir hasta compilar. Verificar que el archivo de pesos está presente en entrega prevista y se encuentra en tiempo de ejecución.
7. Ejecutar tests unitarios/instrumentados si hay emulador, tests JS en navegador y smoke tests de inferencia neuronal REAL (entrada, salida no vacía, sin red) en hardware/emulador compatible. No marcar inferencia aprobada sin haberla ejecutado.
8. Regresión de TODAS las funciones V5/V6: presupuestos, historial, PDF, calculadoras REBT y caída de tensión, ES/EN/FR, escáner cámara/fotos, OCR ML Kit, reconocimiento de componentes, unifilares manuales y automáticos, navegación y accesos IA superior/inferior, persistencia y seguridad. Marcar límites del reconocimiento visual y conexiones ocultas.
9. Entregar HTML independiente con diagnóstico honesto: la IA nativa Android no puede ejecutarse en HTML simple. Para IA neuronal en navegador, integrar un runtime web real y pesos compatibles o indicar explícitamente la limitación; no simular IA neuronal con reglas.
10. Entregar ZIP Android Studio completo, HTML, pruebas automatizadas, instrucciones de compilación, manifiesto de licencias y reporte PASS/FAIL/SKIP con comandos, logs y evidencias. No prometer 100% si hay SKIP.

## CONDICIONES
- Conservar todas las funciones V5 y V6. Sin voz/vídeo. Offline tras entrega del modelo.
- No introducir pesos falsos, APIs ficticias, resultados de pruebas inventados ni descargar código de fuentes dudosas.
- Modelo entregado por Google Play cuando se publique por Play; alternativa importación local para APK sideload.
- Seguridad eléctrica y privacidad por defecto.
- Si el modelo seleccionado no es viable en móviles de gama media, ofrecer alternativa cuantizada más ligera y comparar RAM, licencia y latencia.
- Trabaja autónomamente, sin preguntas salvo bloqueos que requieran autorización externa.

## CRITERIO DE TERMINACIÓN
NO marcar final hasta (a) pesos reales verificados, (b) runtime compila, (c) inferencia real comprobada en entorno compatible, (d) regresión con evidencias, (e) paquetes finales íntegros. Si falta algo, señalar exactamente qué y por qué.

## RESTRICCIÓN EXPRESA DEL USUARIO SOBRE COSTES (V5/V6.10/V6 PRO)
No se autorizan compras, suscripciones, contratación de servicios, APIs de pago, activación de facturación por consumo ni cargos adicionales. Utilizar únicamente recursos gratuitos o ya incluidos. Ante una operación con posible cargo adicional, detenerla antes de ejecutarla, informar del importe conocido y pedir autorización expresa. No asumir ni garantizar condiciones de facturación de la cuenta que no se puedan consultar.
