# V6.1 — Motor unificado y estado neuronal

- La WebView Android y Chrome usan **la misma función JavaScript `askLocal`**. Se elimina la selección del motor Java obsoleto en el botón de consulta.
- `OfflineElectricalAssistant.java` permanece como clase heredada, pero no es el motor usado por la interfaz del asistente.
- La corrección no instala una red neuronal ni pesos: `neuralModelLoaded=false`.
- Para una IA generativa real se requiere integrar LiteRT-LM (recomendación actual de Google) o llama.cpp, incorporar un modelo compatible, verificar licencia y recursos del dispositivo, cargarlo y ejecutar pruebas de inferencia offline.
- Nunca permitir que una salida generativa omita avisos de emergencia: la clasificación de riesgos debe preceder al modelo.
- La detección de humo/fuego sigue basada en reglas y no constituye una certificación de seguridad.
