# Electricista V6 PRO — asistente offline integrado

## Implementado
- Se conserva el código fuente V6 PRO MODELO LOCAL recuperado de la biblioteca.
- Puente Android JavaScript con `AndroidOfflineAssistant.ask`.
- Panel de consultas local en el HTML, con salida como texto seguro (textContent).
- Motor determinista de consultas eléctricas (diferenciales, magnetotérmicos, contactores, tierra, caída de tensión, averías, unifilares).
- Sin peticiones a servidores para estas consultas.

## No implementado / no probado
- NO hay un LLM ya entrenado empaquetado, ni inferencia generativa de texto.
- NO hay modelo de visión eléctrica especializado incorporado: el OCR/detector existente puede dar candidatos genéricos.
- NO se puede inferir con fiabilidad el cableado oculto desde una fotografía.
- No se ha compilado ni instalado la APK en Android; Android Studio descargará dependencias en el primer build.
- No hay certificación de REBT ni garantía de ausencia de errores.

## Compilar
Abrir la carpeta `Electricista_V6_PRO_MODELO_LOCAL` en Android Studio, esperar sincronización Gradle y usar Build > Build APK(s). Para instalar, usar la APK debug generada. La aplicación requiere Android SDK 36 para compilar, minSdk 24. La primera sincronización necesita Internet para dependencias si no están en caché; el asistente por reglas funciona sin Internet después de instalar.

## Modelos abiertos candidatos para futura integración
- Qwen3-0.6B GGUF: https://huggingface.co/Qwen/Qwen3-0.6B-GGUF
- llama.cpp Android: https://github.com/ggml-org/llama.cpp/tree/master/examples/llama.android
Estos enlaces NO implican que los modelos estén incluidos ni ejecutándose.
