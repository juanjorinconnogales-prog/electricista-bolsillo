# V6.3 – Revisión técnica y correcciones

## Cambios
- LiteRT-LM 0.18.0 declarado en Gradle. Código Kotlin de inferencia local y puente WebView presentes.
- Guardarraíl de emergencias tanto en Java como en JavaScript (evita depender del modelo).
- Sustitución de modelos serializada: cierra conversación y motor antes de reemplazar el fichero.
- Fallo neuronal: se muestra la respuesta de reglas con aviso, en lugar de dejar la consulta sin ayuda.
- Se conservan los módulos V5/V6 y los accesos IA superior e inferior.

## Límites de verificación
- Sin pesos .litertlm no existe inferencia neuronal real. Se recomienda Qwen3-0.6B.litertlm (aprox. 586 MB) de litert-community en Hugging Face.
- El proyecto contiene la importación de modelos mediante selector de documentos Android.
- No se ha compilado APK ni ejecutado inferencia real en dispositivo.
- No se garantiza compatibilidad de la API Kotlin hasta resolver dependencias con Gradle y compilar.
- La detección de emergencias es por palabras clave, requiere validación ampliada y no sustituye una evaluación de seguridad.

## Fuentes
- https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill
- https://developers.google.com/edge/litert-lm/android
- https://huggingface.co/litert-community/Qwen3-0.6B
