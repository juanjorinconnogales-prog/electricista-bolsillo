#!/usr/bin/env python3
"""Verifies bytes, never claims inference."""
import sys
from instalar_modelo_oficial import DEST,verify
try: print(verify(DEST));print('Pesos íntegros según pin; inferencia NO verificada por este comando.')
except (OSError, ValueError) as error:print('BLOQUEADO:',error);sys.exit(2)
