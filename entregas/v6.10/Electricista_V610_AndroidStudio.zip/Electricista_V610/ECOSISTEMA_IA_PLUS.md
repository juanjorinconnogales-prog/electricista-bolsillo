# V6 PRO — Ecosistema IA Plus (experimental)

Integración nueva: fusión espacial OCR + regiones visuales, clasificación tentativa por texto, salida JSON de diagnóstico.

Tecnologías públicas: Google ML Kit OCR y detección de objetos. Se mantienen las librerías originales y el proyecto Android Studio.

**Límites:** el detector genérico NO clasifica dispositivos eléctricos por su aspecto, NO aprende pesos neuronales ni determina cableado oculto. Requiere modelo específico entrenado y pruebas con imágenes reales. No certificar esquemas automáticamente.

El reconocimiento OCR funciona offline si el modelo está empaquetado; Gradle requiere conexión inicial para resolver dependencias.

Pruebas: sintaxis de JS, ZIP y coherencia de assets; no se ha compilado APK en Android.
