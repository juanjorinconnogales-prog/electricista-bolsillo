# V6 PRO — Ecosistema OCR espacial (prototipo integrable)

## Implementado en esta entrega
- Se conserva la base V6 existente y sus recursos.
- OCR ML Kit incluido en APK (sin descarga del modelo en primera ejecución).
- El puente Android → HTML transmite líneas detectadas y coordenadas x/y/ancho/alto, además del texto.
- El HTML ordena las etiquetas por posición espacial y conserva los datos en `window.v6LastSpatialOCR`.
- La interpretación y generación de borradores existentes siguen siendo editables.

## NO implementado / NO verificado
- Detección visual de magnetotérmicos sin inscripciones legibles (requiere modelo de detección entrenado y archivo de pesos).
- Inferencia de cableado oculto; jamás debe representarse como conexión confirmada.
- Entrenamiento autónomo de un modelo visual en el móvil. Las correcciones textuales existentes son reglas locales, no entrenamiento neuronal.
- Compilación APK, pruebas en dispositivo y regresión integral V5.

## Próxima integración visual real
Entrenar o adquirir con licencia compatible un detector de aparatos eléctricos, exportarlo a `.tflite` y empaquetarlo con LiteRT; combinar sus cajas con las coordenadas OCR. No introducir una dependencia de detector sin su modelo real.

## Fuentes
https://developers.google.com/ml-kit/vision/text-recognition/v2/android
https://developers.google.com/ml-kit/vision/object-detection/custom-models/android
https://developers.google.com/edge/litert/overview
