# Estado actual

Consultar INFORME_PRUEBAS_V610.md y evidence/. El proyecto V6.10 ya compila APK/AAB y contiene pruebas reproducibles. **No se han obtenido pesos Qwen3 ni verificado inferencia generativa real**; release_gate.py impide dar por válida esa entrega.

El ZIP original se conserva intacto fuera de esta carpeta de trabajo. Los documentos previos de auditoría y pruebas/historico_versiones_anteriores describen ejecuciones anteriores; no sustituyen el informe actual.
