@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0GENERAR_APK_CORREGIDA.ps1"
if errorlevel 1 (
  echo.
  echo No se genero la APK. Revisa el mensaje anterior.
)
pause
