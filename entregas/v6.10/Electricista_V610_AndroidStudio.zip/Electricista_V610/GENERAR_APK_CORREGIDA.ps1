$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
try {
    $candidates = @(
        $env:JAVA_HOME,
        "$env:ProgramFiles\Android\Android Studio\jbr",
        "$env:LOCALAPPDATA\Programs\Android Studio\jbr"
    )
    if (Test-Path "$env:USERPROFILE\.jdks") {
        $candidates += @(Get-ChildItem "$env:USERPROFILE\.jdks" -Directory | Sort-Object LastWriteTime -Descending | Select-Object -ExpandProperty FullName)
    }
    $jdk = $candidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'bin\java.exe')) } | Select-Object -First 1
    if (!$jdk) { throw 'No se encuentra Java. Abre esta carpeta como proyecto en Android Studio y usa Build > Build APK(s).' }
    $env:JAVA_HOME = $jdk
    if (!$env:ANDROID_HOME) { $env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk" }
    if (!(Test-Path $env:ANDROID_HOME)) { throw 'No se encuentra el SDK de Android. Configuralo en Android Studio.' }
    $key = "$env:USERPROFILE\.android\debug.keystore"
    if (!(Test-Path $key)) { throw 'Falta la clave original debug.keystore en este PC. No se creara otra clave para evitar una APK incompatible con la instalada.' }
    $cert = (& (Join-Path $jdk 'bin\keytool.exe') -list -v -keystore $key -alias androiddebugkey -storepass android 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw 'No se puede leer la clave de firma original.' }
    $fingerprint = '6AF4D450DDF6BE066935E81E96A3F41D31AFEF C78966683410559B8C4A73EE60'.Replace(' ','')
    if (!$cert.Replace(':','').ToUpperInvariant().Contains($fingerprint)) { throw 'La clave de este PC no coincide con la APK V4.4. Usa el PC donde se genero esa APK. No desinstales la app.' }
    Write-Host 'Generando V4.5 con la firma original. La primera compilacion puede descargar dependencias.'
    & .\gradlew.bat --no-daemon assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'La compilacion no ha terminado correctamente. Conserva el mensaje para revisarlo.' }
    $apk = Join-Path $PSScriptRoot 'Electricista_Bolsillo_V4_5.apk'
    Copy-Item '.\app\build\outputs\apk\debug\app-debug.apk' $apk -Force
    Write-Host "APK lista: $apk"
    Write-Host 'Actualiza la app instalada con esta APK. No la desinstales. Exporta tus datos antes de actualizar.'
    Start-Process explorer.exe -ArgumentList @('/select,',('"' + $apk + '"'))
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
