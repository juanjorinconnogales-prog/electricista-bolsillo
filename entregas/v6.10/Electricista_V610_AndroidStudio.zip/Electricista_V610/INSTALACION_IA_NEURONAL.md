# Modelo neuronal Qwen3-0.6B para V6.4

El proyecto incorpora código de descarga e instalación **dentro de la app** del archivo oficial `Qwen3-0.6B.litertlm` (~586 MB). La descarga necesita Internet una sola vez; la inferencia LiteRT-LM funciona localmente. Alternativamente se puede importar un archivo .litertlm.

**No se incluye el archivo de pesos en este ZIP**. La app debe descargarlos al primer uso, previa confirmación del usuario. Fuente: https://huggingface.co/litert-community/Qwen3-0.6B

Se cambió el motor Kotlin para usar `sendMessageAsync(...).collect` y `runBlocking` en su hilo único, siguiendo la API oficial. No se ha compilado ni ejecutado en Android; hay que verificar compatibilidad real de Gradle, LiteRT-LM y dispositivo. La app necesita Internet únicamente para instalar el modelo; el permiso INTERNET no implica llamadas en la inferencia.

**Límites**: Qwen3-0.6B es un modelo general, no especializado en REBT ni visión eléctrica. El reconocimiento de cuadros sigue sin modelo visual entrenado. No confiar en respuestas para maniobras peligrosas sin comprobación profesional.
