# V6 PRO — integración OCR + detector geométrico local

- ML Kit OCR latino empaquetado lee inscripciones y devuelve posiciones de líneas.
- ML Kit Object Detection genérico empaquetado devuelve rectángulos de regiones candidatas. **No clasifica dispositivos eléctricos**.
- La capa HTML convierte etiquetas OCR en componentes eléctricos candidatos; si el plano está vacío, genera automáticamente un borrador con **conexiones sin determinar**.
- Mantiene el editor manual para confirmar conexiones. No identifica cableado oculto.
- No se incluye un modelo entrenado específicamente para magnetotérmicos/diferenciales. Para clasificar aparatos por aspecto se requiere un modelo propio entrenado y validado.
- Sin compilación Android ni prueba en dispositivo realizadas en este entorno.
- El reconocimiento local no equivale a aprendizaje autónomo del modelo. Las correcciones de OCR siguen siendo reglas guardadas localmente.
