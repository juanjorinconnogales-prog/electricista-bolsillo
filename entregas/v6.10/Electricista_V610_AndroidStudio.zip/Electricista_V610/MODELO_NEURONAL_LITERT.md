# V6.2 — Integración LiteRT-LM, no validada en dispositivo

Se incorpora la dependencia oficial LiteRT-LM 0.18.0 y el código Kotlin `NeuralElectricalEngine.kt` que carga un modelo real `.litertlm` desde `filesDir`, inicializa el motor en hilo único y genera respuestas mediante `sendMessage`. El WebView llama al puente `AndroidNeuralAI`, que devuelve la respuesta mediante callback JS. Hay importación local desde el selector de documentos de Android, sin acceso a Internet. No se incluyen pesos: **sin un modelo compatible, la app sigue usando reglas**.

Modelo de referencia: https://huggingface.co/litert-community/Qwen3-0.6B (verificar condiciones, tamaño, nombre del archivo y compatibilidad antes de distribuir). Alternativa: https://huggingface.co/litert-community . Un `.gguf` no funciona con LiteRT-LM; necesita `.litertlm`.

Fuentes: https://developers.google.com/edge/litert-lm/android ; https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill ; https://github.com/google-ai-edge/LiteRT-LM

Pendiente: compilar Gradle con acceso a Maven, instalar modelo, inferencia real, compatibilidad CPU/memoria, validación seguridad, licencia del modelo, distribución y pruebas de regresión. No es una versión comercial terminada. Las reglas de emergencia se ejecutan antes del LLM. El HTML en Chrome no ejecuta LiteRT-LM Android; allí permanece el motor de reglas.
