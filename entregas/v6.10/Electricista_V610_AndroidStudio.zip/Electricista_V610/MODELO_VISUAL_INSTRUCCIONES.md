# V6 PRO — Integración de modelo local

## Implementado
- ML Kit OCR local y detector genérico como alternativa.
- Detección automática de un modelo `app/src/main/assets/electrical_classifier.tflite` si está presente.
- Clasificación de regiones con etiquetas y puntuación de confianza (mínimo 0,55) cuando el modelo sea compatible con ML Kit Custom Object Detection.
- Envío de etiquetas y coordenadas al HTML a través del puente `v6VisualCandidates`.
- Los demás módulos de la V5/V6 se conservan sin modificaciones en esta entrega.

## Aún NO implementado ni demostrado
- No se incluye un archivo `.tflite` especializado: no se ha podido obtener y validar legalmente un modelo compatible.
- El modelo de Roboflow publicado en su página funciona mediante API alojada; su licencia de datos CC BY 4.0 no garantiza que los pesos sean descargables ni utilizables comercialmente sin revisar condiciones.
- No se han compilado APK ni hecho pruebas en un teléfono.
- No hay aprendizaje autónomo de pesos en el dispositivo ni deducción fiable de cableado oculto.
- Las etiquetas del modelo se exponen como `boxes[].labels`; su uso para asignar automáticamente símbolos requiere probar el modelo y validar correspondencias de clases.

## Incorporar un modelo
1. Conseguir o entrenar un **clasificador de imágenes** compatible con ML Kit Custom Object Detection (TFLite con metadatos adecuados). No confundirlo con un YOLO detector sin adaptar.
2. Revisar licencia, procedencia y clases. Copiar el archivo como `app/src/main/assets/electrical_classifier.tflite`.
3. Compilar en Android Studio con dependencias Maven descargadas previamente.
4. Fotografiar cuadros reales y comprobar las etiquetas y sus puntuaciones.
5. Mantener la confirmación de conexiones desconocidas antes de generar el unifilar.

Fuentes:
- https://developers.google.com/ml-kit/vision/object-detection/custom-models/android
- https://universe.roboflow.com/bejganas-workspace-atnft/electrical-panel-nby3v
