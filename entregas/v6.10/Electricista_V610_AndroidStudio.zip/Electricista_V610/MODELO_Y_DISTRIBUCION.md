# V6.7: distribución del modelo por Google Play

El módulo `neuralmodel` es un Play Asset Delivery **install-time**. Para tener IA neuronal realmente operativa hay que descargar `Qwen3-0.6B.litertlm` (613722264 bytes) desde https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm y verificar SHA-256 `c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108`.

Colocar el archivo en `neuralmodel/src/main/assets/Qwen3-0.6B.litertlm`, crear un **AAB** y distribuirlo desde Google Play. El modelo se entrega mediante Play y la inferencia no requiere red. Para APK manual, la ruta existente de importación/descarga sigue siendo necesaria; Play Asset Delivery no suministra automáticamente pesos a APK instaladas fuera de Play.

IMPORTANTE: este ZIP no incluye el archivo de 614 MB; no se ha compilado ni probado una inferencia real. El motor JavaScript sigue como alternativa de reglas. La implementación de LiteRT-LM y compatibilidad con dispositivos requieren prueba de compilación y ejecución.
