@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARAR_WRAPPER_WINDOWS.ps1"
if errorlevel 1 (
    echo.
    echo ERROR: la preparacion no ha terminado. Copia el mensaje y preguntanos.
)
pause
