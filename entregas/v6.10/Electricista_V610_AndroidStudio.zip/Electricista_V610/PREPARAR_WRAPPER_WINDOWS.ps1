﻿$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$version = '8.13'
$working = Join-Path $env:TEMP 'electricista_gradle_bootstrap'
$archive = Join-Path $working ('gradle-' + $version + '-bin.zip')
$unpacked = Join-Path $working ('gradle-' + $version)
$bootstrap = Join-Path $working 'proyecto_temporal'
New-Item -ItemType Directory -Force -Path $working,$bootstrap | Out-Null
Write-Host 'Descargando Gradle oficial 8.13 (solo para preparar el proyecto)...'
$dist = "https://services.gradle.org/distributions/gradle-$version-bin.zip"
$hashUrl = "$dist.sha256"
if (!(Test-Path $archive)) { Invoke-WebRequest -Uri $dist -OutFile $archive -UseBasicParsing }
$expected = ((Invoke-WebRequest -Uri $hashUrl -UseBasicParsing).Content | Out-String).Trim().Split(' ')[0].ToLowerInvariant()
$actual = (Get-FileHash $archive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) {
    Remove-Item $archive -Force
    throw "Error de integridad: checksum no coincide. No se ha ejecutado el archivo descargado."
}
Write-Host 'Checksum SHA-256 oficial verificado.'
if (!(Test-Path (Join-Path $unpacked 'bin/gradle.bat'))) {
    Expand-Archive -LiteralPath $archive -DestinationPath $working -Force
}
# Gradle crea el wrapper en un proyecto VACÍO, evitando ejecutar la app antes de que Android Studio instale SDK 36.
Push-Location $bootstrap
try {
    & (Join-Path $unpacked 'bin/gradle.bat') 'wrapper' '--gradle-version' $version
    if ($LASTEXITCODE -ne 0) { throw 'Gradle no pudo generar el wrapper.' }
} finally { Pop-Location }
Copy-Item (Join-Path $bootstrap 'gradle/wrapper/gradle-wrapper.jar') (Join-Path $project 'gradle/wrapper/gradle-wrapper.jar') -Force
Copy-Item (Join-Path $bootstrap 'gradlew.bat') (Join-Path $project 'gradlew.bat') -Force
Copy-Item (Join-Path $bootstrap 'gradlew') (Join-Path $project 'gradlew') -Force
Write-Host ''
Write-Host 'PREPARACION TERMINADA. Ya puedes abrir la carpeta del proyecto en Android Studio.' -ForegroundColor Green
