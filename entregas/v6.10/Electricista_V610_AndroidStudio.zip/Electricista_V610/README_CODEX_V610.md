# Electricista en el Bolsillo V6.10 — entrega auditada

Esta entrega parte exclusivamente de Electricista_V6_10_CODEX.zip. El informe actual es INFORME_PRUEBAS_V610.md; los documentos de auditorías anteriores y pruebas/historico_versiones_anteriores son antecedentes, no evidencias de esta ejecución.

**No hay pesos neuronales en esta entrega. Compilar LiteRT-LM no demuestra inferencia.** El runtime Android compila; el modelo Qwen3 no ha podido descargarse por la política de red. El HTML independiente funciona con biblioteca de reglas y no ejecuta la IA nativa Kotlin.

## Compilar

Android Studio con SDK Android 36, build tools 36.0.0 y JDK completo 17 o 21. Se verificó JDK 21 compilando Java/Kotlin a JVM 17. Gradle Wrapper 8.13 y AGP 8.13.2 están incluidos. Abrir la carpeta que contiene settings.gradle.

```sh
./gradlew assembleDebug bundleRelease assembleDebugAndroidTest testDebugUnitTest lintDebug
```

En Windows usar gradlew.bat. APK debug: app/build/outputs/apk/debug/app-debug.apk. AAB: app/build/outputs/bundle/release/app-release.aab. El AAB sin pesos es solo evidencia de compilación; no está listo para publicar. No se incluyen claves privadas ni firma de publicación.

## Repetir las pruebas web

```sh
npm install
npx playwright install chromium
python pruebas/run_web_tests.py
```

Opcional: CHROMIUM_EXECUTABLE apunta a un Chromium local. El runner sirve el proyecto en 127.0.0.1:8765. Registra cada resultado en evidence/. Las pruebas de contratos de archivos en navegador capturan los bytes del puente; no equivalen a abrir una aplicación externa Android.

HTML principal: fuentes-web/index.html; copia idéntica para la APK: app/src/main/assets/index.html. Para reconstruir compatibilidad con WebView 83:

```sh
npm run build:compat
```

Se conservan los módulos PDF.js originales en fuentes-web/vendor/. El resultado integra core-js y transforma sintaxis de los módulos sin recursos de red. No ejecutar los JS sueltos históricos para reconstruir la página: el HTML contiene las ampliaciones V6.10.

## Instalar pesos reales y comprobar inferencia

```sh
python instalar_modelo_oficial.py
python verificar_modelo_antes_de_publicar.py
./gradlew assembleDebug bundleRelease
```

El tamaño exigido es exactamente **613722264 bytes**, según los metadatos facilitados por el usuario. El instalador no acepta archivos por su tamaño solamente: exige el SHA-256 fijado en MODEL_MANIFEST.json. Este pin coincide con el ZIP recibido y ha sido confirmado expresamente por el usuario; su procedencia remota no se pudo confirmar de forma independiente y debe cotejarse antes de publicar. No modificarlo para aceptar una descarga desconocida.

Si el archivo está disponible localmente, incorporarlo al proyecto sin ninguna descarga:

```sh
python instalar_modelo_oficial.py --from-file /workspace/Qwen3-0.6B.litertlm
```

El comando verifica tamaño exacto y SHA antes de copiar; conserva el modelo previo si la comprobación falla. En Android se utiliza el botón «Importar Qwen3 verificado (.litertlm)» y el selector de archivos. El runtime repite ambas comprobaciones antes de inicializar el modelo. No se ha ejecutado la ruta positiva con pesos reales en esta entrega, porque la descarga sigue bloqueada.

Google Play: neuralmodel es un asset pack install-time. Una APK instalada manualmente debe importar el mismo Qwen3 validado mediante el selector de la app; no contiene ese asset pack como si fuera un AAB.

En dispositivo/emulador compatible, instalar APK y APK de pruebas, desactivar datos y Wi-Fi y ejecutar:

```sh
adb shell cmd connectivity airplane-mode enable
adb shell svc wifi disable
adb shell svc data disable
adb shell am instrument -w -r com.juanjo.electricistabolsillov42.pruebas.test/androidx.test.runner.AndroidJUnitRunner
```

DeviceVerificationTest comprueba OCR real, manejo de pesos ausentes, WebView/presupuestos/planos/PDF y contiene la prueba de inferencia nativa. La inferencia se omite explícitamente si faltan pesos. Cuando están presentes comprueba hash y ausencia de red, ejecuta la generación y guarda files/neural-evidence.json con entrada, salida, duración, ABI y PSS observado (no pico de memoria).

```sh
adb shell run-as com.juanjo.electricistabolsillov42.pruebas cat files/neural-evidence.json > evidence/neural-evidence.json
python release_gate.py
```

release_gate.py debe fallar mientras falten pesos o evidencia. El helper pruebas/device_runner.py usa el protocolo ADB para un emulador local de pruebas en 127.0.0.1:5555 (pip install adb-shell); no evita autenticación ni restricciones de red.

Las pruebas unitarias incluyen 5 casos, con rechazo de una importación incompleta. La última ejecución instrumentada dio 3 PASS y 1 SKIP: WebView/PDF, OCR y pesos ausentes aprobados; inferencia generativa omitida por ausencia de pesos. El emulador sufrió ANR de System UI; no se certifica fluidez en hardware físico.

## Límites

No hay pruebas físicas ARM64, de cámara real, de aplicaciones externas de compartir/imprimir, de entrega desde Play ni de inferencia generativa válida. Un clasificador eléctrico .tflite no está incluido; el OCR no identifica cableado oculto. Los cálculos siguen siendo comprobaciones orientativas de caída de tensión y no un dimensionamiento reglamentario completo. Consultar el informe para el estado detallado PASS/FAIL/SKIP.
