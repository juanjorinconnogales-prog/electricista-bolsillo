# Estado técnico comprobado — 24/10/2026

**Veredicto: IA neuronal NO OPERATIVA NI DEMOSTRADA.**

- Existe integración de código LiteRT-LM y puente WebView/Android.
- El asset pack neuralmodel no incluye ningún archivo `.litertlm`: solo un marcador de texto.
- No hay APK/AAB compilado ni inferencia real verificada.
- En este entorno no hay Android SDK/Gradle ni acceso DNS a huggingface.co; no se pueden resolver dependencias ni descargar pesos.
- Se incluye `verificar_modelo_antes_de_publicar.py` que bloquea la preparación para publicación si falta el modelo o no coincide el hash esperado.
- No se ha comprobado la validez del hash publicado contra el servidor oficial desde este entorno; antes de distribuir es necesario confirmarlo.
- El motor de reglas offline sí está incluido, pero no sustituye a un LLM.

**Requisitos para finalizar:** obtener pesos oficiales con licencia y hash verificado, integrarlos en `neuralmodel/src/main/assets/Qwen3-0.6B.litertlm`, compilar AAB con SDK y dependencias, ejecutar inferencia en dispositivo compatible y realizar regresión V5/V6.
