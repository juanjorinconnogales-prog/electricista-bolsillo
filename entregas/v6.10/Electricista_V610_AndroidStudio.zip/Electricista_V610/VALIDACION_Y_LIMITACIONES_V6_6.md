# Electricista V6.6 — revisión de integración neuronal

## Corregido en código
- Sustitución de modelo con respaldo y restauración si falla la instalación.
- El motor de reglas de emergencia intercepta consultas antes de inferencia.
- El modelo se descarga o importa; **no está incluido en este ZIP**.
- El motor LiteRT-LM está declarado como dependencia, pero no se ha ejecutado en Android.

## No certificado
- Compilación Gradle/Android, resolución real de dependencias, compatibilidad de API LiteRT-LM 0.18.0, carga del archivo `.litertlm`, inferencia y rendimiento en el teléfono.
- Integridad del modelo descargado: la suma SHA-256 declarada en código debe contrastarse con el artefacto remoto actual antes de confiar en la descarga.
- Reconocimiento visual neuronal de cuadros y planos.

## Para una validación definitiva
Se necesita SDK Android, acceso a repositorios Maven y el archivo real del modelo; después compilar y ejecutar una prueba de inferencia en un dispositivo o emulador compatible. No se debe comercializar como IA neuronal validada hasta entonces.
