# V6.5 — auditoría de integración LiteRT-LM

Se conserva V6.4 y se añade comprobación SHA-256 del modelo oficial descargado antes de activarlo, además de recuperación del motor tras un fallo de inferencia.

- Modelo: Qwen3-0.6B.litertlm (archivo de ~614 MB decimales, no incluido en este ZIP).
- Fuente: https://huggingface.co/litert-community/Qwen3-0.6B
- SHA-256 oficial: c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108
- Motor: com.google.ai.edge.litertlm:litertlm-android:0.18.0.
- Descarga únicamente inicial; inferencia diseñada para uso sin conexión.

**Límites:** sin pesos locales, sin APK compilada y sin dispositivo Android para ejecutar inferencia. La existencia de la integración no demuestra que el modelo funcione en el móvil. No se ha verificado el reconocimiento visual especializado ni toda la regresión V5.
