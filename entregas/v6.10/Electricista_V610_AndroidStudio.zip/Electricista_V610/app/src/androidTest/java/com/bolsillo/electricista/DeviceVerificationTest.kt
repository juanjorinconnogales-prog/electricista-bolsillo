package com.bolsillo.electricista

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeviceVerificationTest {
 private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
 @Test fun nativeWebViewLoadsFunctionsAndSafety() {
  val instrumentation=InstrumentationRegistry.getInstrumentation()
  val intent=android.content.Intent(context,MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
  val activity=instrumentation.startActivitySync(intent)
  val field=MainActivity::class.java.getDeclaredField("web");field.isAccessible=true
  val web=field.get(activity) as android.webkit.WebView
  fun evaluate(js:String):String {
   val latch=CountDownLatch(1);var result=""
   instrumentation.runOnMainSync { web.evaluateJavascript(js) {result=it;latch.countDown()} }
   assertTrue("WebView callback timeout",latch.await(60,TimeUnit.SECONDS));return result
  }
  try {
   val loadDeadline=System.currentTimeMillis()+120000
   var progress=0
   while(progress<100&&System.currentTimeMillis()<loadDeadline){
    instrumentation.runOnMainSync {progress=web.progress};Thread.sleep(500)
   }
   val deadline=System.currentTimeMillis()+120000
   while(evaluate("typeof window.ElectricistaAI")!="\"object\""&&System.currentTimeMillis()<deadline)Thread.sleep(500)
   assertEquals("\"object\"",evaluate("typeof window.ElectricistaAI"))
   assertEquals("\"object\"",evaluate("typeof window.AndroidNeuralAI"))
   assertEquals("\"boolean\"",evaluate("typeof AndroidNeuralAI.installed()"))
   val safety=evaluate("ElectricistaAI.askLocal('electrocución y humo en cuadro')")
   assertTrue(safety.contains("112"))
   val budget=evaluate("document.getElementById('solicitudUsuario').value='Inspección';document.getElementById('horasTrabajo').value=2;document.getElementById('tarifaHora').value=40;generarPresupuestoProfesional();document.getElementById('montoTotal').textContent")
   assertTrue(budget.contains("96,80"))
   assertEquals("254",evaluate("Planos44.symbols.length"))
   assertEquals("\"object\"",evaluate("typeof window.pdfjs44"))
   evaluate("window.nativePdfResult='pending';Planos44.setModel({...Planos44.getModel(),nodes:[]});Planos44.templates('clocklight');Planos44.pdf().arrayBuffer().then(b=>pdfjs44.getDocument({data:new Uint8Array(b),useSystemFonts:true,isEvalSupported:false}).promise).then(pdf=>window.nativePdfResult='pages:'+pdf.numPages).catch(e=>window.nativePdfResult='error:'+e.message);'started'")
   val pdfDeadline=System.currentTimeMillis()+90000
   var pdfResult=evaluate("window.nativePdfResult")
   while(pdfResult.contains("pending")&&System.currentTimeMillis()<pdfDeadline){Thread.sleep(500);pdfResult=evaluate("window.nativePdfResult")}
   assertTrue("PDF import failed: $pdfResult",pdfResult.contains("pages:"))
   evaluate("document.getElementById('eai-toggle').click();document.getElementById('eai-question').value='humo en cuadro';document.getElementById('eai-send').click()")
   val response=evaluate("document.getElementById('eai-output').textContent")
   assertTrue(response.contains("112"));assertFalse(response.contains("IA neuronal local:"))
   File(context.filesDir,"webview-evidence.txt").writeText("Symbols=254\nBudget="+budget+"\nSafety="+response)
   val image=instrumentation.uiAutomation.takeScreenshot()
   if(image!=null){java.io.FileOutputStream(File(context.filesDir,"webview-evidence.png")).use {image.compress(Bitmap.CompressFormat.PNG,100,it)};image.recycle()}
  } finally {instrumentation.runOnMainSync {activity.finish()} }
 }
 @Test fun bundledOcrReadsActualPixels() {
  val bitmap=Bitmap.createBitmap(900,260,Bitmap.Config.ARGB_8888)
  val canvas=Canvas(bitmap);canvas.drawColor(Color.WHITE)
  val paint=Paint(Paint.ANTI_ALIAS_FLAG);paint.color=Color.BLACK;paint.textSize=80f
  canvas.drawText("C16 230V 30mA",30f,150f,paint)
  val latch=CountDownLatch(1);var text="";var failure:Exception?=null
  val client=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
  client.process(InputImage.fromBitmap(bitmap,0)).addOnSuccessListener {text=it.text;latch.countDown()}
   .addOnFailureListener {failure=it;latch.countDown()}
  assertTrue("OCR timeout",latch.await(90,TimeUnit.SECONDS));client.close();bitmap.recycle()
  if(failure!=null)throw failure!!
  assertTrue("Actual OCR output: $text",text.contains("C16"))
  File(context.filesDir,"ocr-evidence.txt").writeText(text)
 }
 @Test fun missingWeightsNeverReturnNeuralSuccess() {
  val engine=NeuralElectricalEngine(context)
  try {
   assumeTrue("Only applies to an installation without weights",!engine.installed())
   val latch=CountDownLatch(1);var ok=true;var answer=""
   engine.ask("Qué es un contactor") {a,n->answer=a;ok=n;latch.countDown()}
   assertTrue(latch.await(15,TimeUnit.SECONDS));assertFalse(ok);assertTrue(answer.contains("Faltan"))
  }finally{engine.close()}
 }
 @Test fun actualNeuralInferenceWithInstalledWeights() {
  val engine=NeuralElectricalEngine(context)
  try {
   assumeTrue("SKIP: genuine verified weights not installed. No inference claimed.",engine.installed())
   val local=File(context.filesDir,"electrical-model.litertlm")
   val assets=com.google.android.play.core.assetpacks.AssetPackManagerFactory.getInstance(context).getPackLocation("neuralmodel")?.assetsPath()
   val model=assets?.let {File(it,"Qwen3-0.6B.litertlm")}?.takeIf {it.isFile}?:local
   val digest=java.security.MessageDigest.getInstance("SHA-256")
   model.inputStream().use {input->val bytes=ByteArray(1024*1024);var n=input.read(bytes);while(n!=-1){digest.update(bytes,0,n);n=input.read(bytes)}}
   val hash=digest.digest().joinToString(""){"%02x".format(it.toInt() and 255)}
   assertEquals("c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108",hash)
   val descriptor=InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand("dumpsys connectivity")
   val connectivity=java.io.FileInputStream(descriptor.fileDescriptor).bufferedReader().use {it.readText()};descriptor.close()
   assertTrue("Disable device connectivity before the inference test",connectivity.contains("Active default network: none"))
   val latch=CountDownLatch(1);var ok=false;var answer=""
   val start=System.nanoTime()
   engine.ask("Explica en una frase qué es un contactor. /no_think") {a,n->answer=a;ok=n;latch.countDown()}
   assertTrue("Inference callback timeout",latch.await(135,TimeUnit.SECONDS))
   assertTrue("Native generation failed: $answer",ok);assertTrue(answer.trim().length>10)
   val evidence=org.json.JSONObject().put("status","PASS").put("runtime","LiteRT-LM 0.18.0").put("backend","CPU")
    .put("model_sha256",hash).put("offline_network_check",true).put("abi",android.os.Build.SUPPORTED_ABIS[0])
    .put("elapsed_ms",(System.nanoTime()-start)/1000000).put("observed_pss_kb",android.os.Debug.getPss())
    .put("input","Explica en una frase qué es un contactor. /no_think").put("output",answer)
   File(context.filesDir,"neural-evidence.json").writeText(evidence.toString(2))
   File(context.filesDir,"neural-evidence.txt").writeText("Runtime=LiteRT-LM 0.18.0\nElapsedMs="+(System.nanoTime()-start)/1000000+"\nInput=Explica en una frase qué es un contactor. /no_think\nOutput="+answer)
  }finally{engine.close()}
 }
}
