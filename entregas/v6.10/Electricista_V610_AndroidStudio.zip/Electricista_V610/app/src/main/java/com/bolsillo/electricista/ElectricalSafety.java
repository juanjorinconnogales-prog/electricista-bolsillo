package com.bolsillo.electricista;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/** Deterministic guard shared by both native assistants. Never a neural result. */
public final class ElectricalSafety {
    private ElectricalSafety() {}
    private static final Pattern DANGER = Pattern.compile(
        "humo|humareda|incend|fuego|llamas|chisp|arco electric|quemad|ardiendo|"
        + "electrocu|calambre|descarga electrica|smoke|fire|spark|burning|electric shock|"
        + "fumee|incendie|flamme|etincelle|brule|electris|choc electrique");
    public static boolean isEmergency(String question) {
        String normalized = Normalizer.normalize(question == null ? "" : question.toLowerCase(Locale.ROOT),
            Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return DANGER.matcher(normalized).find();
    }
    public static String emergencyAnswer() {
        return "⚠️ EMERGENCIA ELÉCTRICA: aléjate, no abras ni toques el cuadro ni a una persona "
            + "en contacto con la corriente. No uses agua. Llama al 112 desde un lugar seguro. "
            + "Corta la alimentación SOLO desde un punto seguro y sin exponerte. "
            + "No restablezcas la tensión hasta una revisión profesional.";
    }
    /** Conservative filter, not a proof that generated advice is safe. */
    public static boolean rejectsGeneratedAdvice(String answer) {
        if (answer == null || answer.trim().isEmpty()) return true;
        String q = Normalizer.normalize(answer.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
            .replaceAll("\\p{M}", "");
        return Pattern.compile("(?:puentea|anula|elimina) (?:el |la )?(?:diferencial|proteccion)|"
            + "trabaja (?:con|bajo) tension|toca (?:el |los )?(?:cable|conductor).*tension").matcher(q).find();
    }
}
