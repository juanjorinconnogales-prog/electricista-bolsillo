package com.bolsillo.electricista;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.json.JSONObject;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends androidx.activity.ComponentActivity {
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final int REQ_FILE = 201;
    private static final int REQ_NEURAL_MODEL = 290;
    private static final int REQ_SAVE_OLD_ANDROID = 202;
    private static final int MAX_BASE64_CHARS = 24 * 1024 * 1024;
    private WebView web;
    private NeuralElectricalEngine neuralEngine;
    private SwipeRefreshLayout swipeRefresh;
    private Uri pendingCameraUri;
    private File pendingCameraFile;
    private android.webkit.ValueCallback<Uri[]> fileChooser;
    private byte[] pendingBytes;
    private String pendingName;
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private WebViewAssetLoader assetLoader;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        neuralEngine = new NeuralElectricalEngine(this);
        web = new WebView(this);
        // System-bar insets are applied to the parent, reducing the real WebView viewport.
        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.addView(web);
        setContentView(swipeRefresh);
        // Recargar limpia los campos temporales, pero NO borra localStorage ni el historial.
        swipeRefresh.setOnChildScrollUpCallback((parent, child) -> web.canScrollVertically(-1));
        swipeRefresh.setOnRefreshListener(() -> web.reload());
        ViewCompat.setOnApplyWindowInsetsListener(swipeRefresh, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return windowInsets;
        });
        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // selección de fotos mediante el selector de Android
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // Solamente se carga HTML incluido dentro de la propia APK (no se ejecutan scripts remotos).
        web.addJavascriptInterface(new FilesBridge(), "AndroidFiles");
        web.addJavascriptInterface(new V6OCRBridge(), "AndroidV6OCR");
        web.addJavascriptInterface(new OfflineAssistantBridge(), "AndroidOfflineAssistant");
        web.addJavascriptInterface(new NeuralBridge(), "AndroidNeuralAI");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) &&
                        "appassets.androidplatform.net".equals(url.getHost())) {
                    return assetLoader.shouldInterceptRequest(url);
                }
                // Bloquea cualquier recurso externo para que el puente no esté expuesto a contenido remoto.
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("appassets.androidplatform.net".equals(url.getHost())) return false;
                if (request.isForMainFrame() && "https".equals(url.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); } catch(Exception ignore) { }
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, android.webkit.ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileChooser != null) fileChooser.onReceiveValue(null);
                fileChooser = callback;
                try {
                    Intent gallery = params.createIntent();
                    String[] accepts = params.getAcceptTypes();
                    boolean images = false;
                    if (accepts != null) for (String accept : accepts) {
                        if (accept != null && (accept.startsWith("image/") || accept.equals("*/*"))) images = true;
                    }
                    if (images) {
                        // Camera via system app: no CAMERA permission needed.
                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) {
                            File dir = new File(getCacheDir(), "fotos_cuadro");
                            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Carpeta de cámara");
                            pendingCameraFile = File.createTempFile("cuadro_", ".jpg", dir);
                            pendingCameraUri = FileProvider.getUriForFile(MainActivity.this,
                                    getPackageName() + ".fileprovider", pendingCameraFile);
                            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            Intent chooser = Intent.createChooser(gallery, "Elegir foto del cuadro");
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                            startActivityForResult(chooser, REQ_FILE);
                        } else {
                            startActivityForResult(gallery, REQ_FILE);
                        }
                    } else {
                        startActivityForResult(gallery, REQ_FILE);
                    }
                    return true;
                } catch (Exception e) {
                    if (fileChooser != null) fileChooser.onReceiveValue(null);
                    fileChooser = null;
                    pendingCameraUri = null;
                    showToast("No se pudo abrir cámara o galería: " + e.getMessage());
                    return true;
                }
            }
        });
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (web != null && web.canGoBack()) web.goBack(); else finish();
            }
        });
        web.loadUrl(HOME);
    }

    private static final class OfflineAssistantBridge {
        @JavascriptInterface public String ask(String question) {
            return OfflineElectricalAssistant.answer(question);
        }
        @JavascriptInterface public String capabilities() {
            return "Biblioteca eléctrica local basada en reglas. Sin modelo generativo instalado.";
        }
    }

    /** Bridge solo para PDF/JSON producidos por el HTML empaquetado. */
    // Bundled ML Kit Latin OCR: processes bitmap on device, no cloud OCR requests.
    private final class V6OCRBridge {
        @JavascriptInterface public void recognize(String base64) {
            try {
                if (base64 == null || base64.length() > 16000000) throw new IllegalArgumentException("Imagen demasiado grande");
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                BitmapFactory.Options opt = new BitmapFactory.Options();
                opt.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opt);
                opt.inSampleSize = Math.max(1, Math.max(opt.outWidth, opt.outHeight) / 2200);
                opt.inJustDecodeBounds = false;
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opt);
                if (bitmap == null) throw new IllegalArgumentException("Imagen no válida");
                // Detección geométrica genérica: candidatos visuales, sin atribuirles tipo eléctrico.
                // Si existe un clasificador eléctrico compatible y autorizado, úsalo sin red.
                // De lo contrario conserva el detector genérico, sin fingir categorías.
                boolean customReady = false;
                try (java.io.InputStream modelCheck = getAssets().open("electrical_classifier.tflite")) {
                    customReady = modelCheck.read() != -1;
                } catch (java.io.IOException ignored) { }
                if (customReady) {
                    try {
                        com.google.mlkit.common.model.LocalModel model =
                            new com.google.mlkit.common.model.LocalModel.Builder()
                                .setAssetFilePath("electrical_classifier.tflite").build();
                        com.google.mlkit.vision.objects.custom.CustomObjectDetectorOptions customOptions =
                            new com.google.mlkit.vision.objects.custom.CustomObjectDetectorOptions.Builder(model)
                                .setDetectorMode(com.google.mlkit.vision.objects.custom.CustomObjectDetectorOptions.SINGLE_IMAGE_MODE)
                                .enableMultipleObjects().enableClassification()
                                .setClassificationConfidenceThreshold(0.55f)
                                .setMaxPerObjectLabelCount(3).build();
                        com.google.mlkit.vision.objects.ObjectDetection.getClient(customOptions)
                            .process(InputImage.fromBitmap(bitmap, 0))
                            .addOnSuccessListener(objects -> sendVisualCandidates(objects, null))
                            .addOnFailureListener(error -> sendVisualCandidates(null, "Clasificador local: " + error.getMessage()));
                    } catch (Exception error) { sendVisualCandidates(null, "Modelo incompatible: " + error.getMessage()); }
                } else {
                com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions options =
                    new com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions.Builder()
                    .setDetectorMode(com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions.SINGLE_IMAGE_MODE)
                    .enableMultipleObjects().build();
                com.google.mlkit.vision.objects.ObjectDetection.getClient(options)
                    .process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener(objects -> sendVisualCandidates(objects, null))
                    .addOnFailureListener(error -> sendVisualCandidates(null, error.getMessage()));
                }
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener(result -> sendOCR(result, null))
                    .addOnFailureListener(error -> sendOCR(null, error.getMessage()));
            } catch (Exception error) { sendOCR(null, error.getMessage()); }
        }
        private void sendVisualCandidates(java.util.List<com.google.mlkit.vision.objects.DetectedObject> objects, String error) {
            try {
                JSONObject data = new JSONObject();
                org.json.JSONArray boxes = new org.json.JSONArray();
                if (objects != null) for (com.google.mlkit.vision.objects.DetectedObject o : objects) {
                    android.graphics.Rect r = o.getBoundingBox();
                    JSONObject b = new JSONObject();
                    b.put("x", r.left); b.put("y", r.top);
                    b.put("w", r.width()); b.put("h", r.height());
                    b.put("kind", "unclassified");
                    org.json.JSONArray labels = new org.json.JSONArray();
                    for (com.google.mlkit.vision.objects.DetectedObject.Label label : o.getLabels()) {
                        JSONObject item = new JSONObject();
                        item.put("text", label.getText()); item.put("confidence", label.getConfidence());
                        labels.put(item);
                    }
                    b.put("labels", labels);
                    boxes.put(b);
                }
                data.put("boxes", boxes);
                if (error != null) data.put("error", error);
                String payload = JSONObject.quote(data.toString());
                runOnUiThread(() -> web.evaluateJavascript("window.v6VisualCandidates && window.v6VisualCandidates(" + payload + ")", null));
            } catch (Exception ignored) { }
        }
        // Estructura espacial del OCR: cada línea conserva sus coordenadas en la fotografía.
        // Esto permite agrupar etiquetas por aparatos sin suponer conexiones ocultas.
        private void sendOCR(com.google.mlkit.vision.text.Text result, String error) {
            try {
                JSONObject data = new JSONObject();
                data.put("text", result == null ? "" : result.getText());
                data.put("engine", "mlkit-latin-bundled");
                org.json.JSONArray lines = new org.json.JSONArray();
                if (result != null) for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks()) {
                    for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                        JSONObject item = new JSONObject();
                        item.put("text", line.getText());
                        android.graphics.Rect r = line.getBoundingBox();
                        if (r != null) {
                            item.put("x", r.left); item.put("y", r.top);
                            item.put("w", r.width()); item.put("h", r.height());
                        }
                        lines.put(item);
                    }
                }
                data.put("lines", lines);
                if (error != null) data.put("error", error);
                String payload = JSONObject.quote(data.toString());
                runOnUiThread(() -> web.evaluateJavascript("window.v6OcrComplete(" + payload + ")", null));
            } catch (Exception ignored) { }
        }
    }

    private final class FilesBridge {
        // Drawing gestures must not be intercepted by pull-to-refresh.
        @JavascriptInterface public void setPlanInteraction(boolean active) {
            runOnUiThread(() -> {
                if (swipeRefresh != null) {
                    swipeRefresh.setEnabled(!active);
                    if (active) swipeRefresh.setRefreshing(false);
                }
            });
        }

        @JavascriptInterface public void saveFile(String name, String mimeType, String base64) {
            transfer(name, mimeType, base64, 0);
        }
        @JavascriptInterface public void sharePdf(String name, String base64) {
            transfer(name, "application/pdf", base64, 1);
        }
        @JavascriptInterface public void openPdf(String name, String base64) {
            transfer(name, "application/pdf", base64, 2);
        }
        private void transfer(String name, String mimeType, String base64, int mode) {
            if (name == null || base64 == null || base64.length() > MAX_BASE64_CHARS) {
                showToast("PDF demasiado grande o sin contenido"); return;
            }
            boolean pdf = "application/pdf".equals(mimeType);
            boolean json = "application/json".equals(mimeType) || "text/json".equals(mimeType);
            boolean csv = "text/csv".equals(mimeType) || "text/csv;charset=utf-8".equals(mimeType);
            if ((!pdf && !json && !csv) || (mode != 0 && !pdf)) {
                showToast("Tipo de archivo no permitido"); return;
            }
            String safe = cleanName(name, pdf ? ".pdf" : csv ? ".csv" : ".json");
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > 18 * 1024 * 1024) throw new IllegalArgumentException("Tamaño no válido");
                if (pdf && !startsAsPDF(bytes)) throw new IllegalArgumentException("Cabecera PDF no válida");
                if (json && !looksLikeJson(bytes)) throw new IllegalArgumentException("JSON no válido");
                if (mode != 0) runOnUiThread(() -> sharePdfNative(safe, bytes, mode == 2));
                else runOnUiThread(() -> saveNative(safe, mimeType, bytes));
            } catch (Exception e) {
                showToast("No se pudo preparar el archivo: " + e.getMessage());
            }
        }
    }
    private static boolean startsAsPDF(byte[] bytes) {
        return bytes.length >= 5 && bytes[0]=='%' && bytes[1]=='P' && bytes[2]=='D' && bytes[3]=='F' && bytes[4]=='-';
    }
    private static boolean looksLikeJson(byte[] bytes) {
        String start = new String(bytes, 0, Math.min(20, bytes.length), java.nio.charset.StandardCharsets.UTF_8).trim();
        return start.startsWith("{") || start.startsWith("[");
    }
    private static String cleanName(String name, String extension) {
        String clean = name.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
        if (clean.length() > 80) clean = clean.substring(0, 80);
        if (!clean.toLowerCase(Locale.ROOT).endsWith(extension)) clean += extension;
        return clean;
    }

    private void saveNative(String name, String mimeType, byte[] bytes) {
        if (Build.VERSION.SDK_INT >= 29) {
            ioExecutor.execute(() -> {
                Uri created = null;
                try {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/Electricista en el Bolsillo");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    created = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (created == null) throw new IOException("No se pudo crear el fichero");
                    try (OutputStream out = getContentResolver().openOutputStream(created)) {
                        if (out == null) throw new IOException("No se pudo escribir");
                        out.write(bytes);
                    }
                    ContentValues ready = new ContentValues();
                    ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(created, ready, null, null);
                    showToast("Guardado en Descargas / Electricista en el Bolsillo: " + name);
                } catch (Exception e) {
                    if (created != null) try { getContentResolver().delete(created, null, null); } catch(Exception ignored) {}
                    showToast("Error al guardar: " + e.getMessage());
                }
            });
        } else { // Android 7-9: selector oficial de guardado sin pedir acceso general a archivos.
            pendingName = name;
            pendingBytes = bytes;
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType(mimeType);
            create.putExtra(Intent.EXTRA_TITLE, name);
            try { startActivityForResult(create, REQ_SAVE_OLD_ANDROID); }
            catch (Exception e) { pendingBytes = null; showToast("No se pudo abrir el guardado"); }
        }
    }

    private void sharePdfNative(String name, byte[] bytes, boolean open) {
        ioExecutor.execute(() -> {
            try {
                File dir = new File(getCacheDir(), "pdf_compartidos");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("No se pudo preparar carpeta");
                File file = new File(dir, name);
                try (FileOutputStream output = new FileOutputStream(file)) { output.write(bytes); }
                Uri uri = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", file);
                runOnUiThread(() -> {
                    try {
                        Intent send = new Intent(open ? Intent.ACTION_VIEW : Intent.ACTION_SEND);
                        if (open) send.setDataAndType(uri, "application/pdf");
                        else send.setType("application/pdf");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.setClipData(ClipData.newUri(getContentResolver(), "Presupuesto PDF", uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, open ? "Abrir presupuesto PDF" : "Compartir presupuesto PDF"));
                    } catch(Exception e){ showToast("Error al compartir: " + e.getMessage()); }
                });
            } catch(Exception e) { showToast("Error al preparar el PDF: " + e.getMessage()); }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileChooser != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                if (resultCode == RESULT_OK && (result == null || result.length == 0)
                        && pendingCameraUri != null && pendingCameraFile != null
                        && pendingCameraFile.exists() && pendingCameraFile.length() > 0) {
                    result = new Uri[]{pendingCameraUri};
                }
                fileChooser.onReceiveValue(result);
                fileChooser = null;
                pendingCameraUri = null;
                pendingCameraFile = null;
            }
        } else if(requestCode == REQ_NEURAL_MODEL) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                ioExecutor.execute(() -> {
                    File tmp = new File(getFilesDir(), "electrical-model.litertlm.tmp");
                    File dest = new File(getFilesDir(), "electrical-model.litertlm");
                    try (InputStream input = getContentResolver().openInputStream(uri);
                         OutputStream output = new FileOutputStream(tmp)) {
                        if (input == null) throw new IOException("No se pudo leer modelo");
                        byte[] buffer = new byte[1024 * 1024]; int n; long total = 0;
                        while ((n = input.read(buffer)) != -1) {
                            total += n;
                            if (total > ModelIntegrity.EXPECTED_BYTES) throw new IOException("Modelo demasiado grande");
                            output.write(buffer, 0, n);
                        }
                        if (total != ModelIntegrity.EXPECTED_BYTES) throw new IOException("Se requieren exactamente " + ModelIntegrity.EXPECTED_BYTES + " bytes");
                        verifyQwenChecksum(tmp);
                        neuralEngine.closeForModelReplacement();
                        replaceModelSafely(tmp, dest);
                        notifyNeuralImport("Modelo importado (" + (total / 1048576) + " MiB). Listo para intentar cargar.");
                    } catch (Exception e) {
                        tmp.delete(); notifyNeuralImport("Error al importar: " + e.getMessage());
                    }
                });
            }
        } else if(requestCode == REQ_SAVE_OLD_ANDROID) {
            byte[] contents = pendingBytes;
            pendingBytes = null;
            pendingName = null;
            if (resultCode == RESULT_OK && contents != null && data != null && data.getData() != null) {
                Uri uri = data.getData();
                ioExecutor.execute(() -> {
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new IOException("No se pudo crear archivo");
                        out.write(contents);
                        showToast("Archivo guardado correctamente");
                    } catch (Exception e) { showToast("Error al guardar: " + e.getMessage()); }
                });
            }
        }
    }
    private void showToast(String text) { runOnUiThread(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show()); }

    public class NeuralBridge {
        @JavascriptInterface public void cancel() { neuralEngine.cancel(); }
        @JavascriptInterface public boolean installed() { return neuralEngine.installed(); }
        /** Descarga oficial, una sola vez. Tras instalar el modelo, inferencia 100% offline. */
        @JavascriptInterface public void downloadModel() {
            ioExecutor.execute(() -> {
                final String source = "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm";
                File tmp = new File(getFilesDir(), "electrical-model.litertlm.download");
                File dest = new File(getFilesDir(), "electrical-model.litertlm");
                HttpURLConnection conn = null;
                try {
                    notifyNeuralImport("Descargando Qwen3-0.6B (aprox. 586 MB). Requiere Internet solo para la instalación…");
                    conn = (HttpURLConnection) new URL(source).openConnection();
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(45000);
                    conn.setInstanceFollowRedirects(true);
                    conn.connect();
                    if (conn.getResponseCode() != 200) throw new IOException("HTTP " + conn.getResponseCode());
                    long expected = conn.getContentLengthLong();
                    if (expected > 0 && expected != ModelIntegrity.EXPECTED_BYTES) throw new IOException("Tamaño anunciado distinto de " + ModelIntegrity.EXPECTED_BYTES + " bytes");
                    long total = 0; long lastUpdate = 0;
                    try (InputStream input = conn.getInputStream(); OutputStream output = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[256 * 1024]; int n;
                        while ((n = input.read(buf)) != -1) {
                            total += n;
                            if (total > ModelIntegrity.EXPECTED_BYTES) throw new IOException("Descarga demasiado grande");
                            output.write(buf, 0, n);
                            if (total - lastUpdate >= 32L * 1024 * 1024) {
                                lastUpdate = total;
                                notifyNeuralImport("Modelo: " + (total / 1048576) + " MiB descargados" + (expected > 0 ? " / " + (expected / 1048576) + " MiB" : ""));
                            }
                        }
                    }
                    if (total != ModelIntegrity.EXPECTED_BYTES || (expected > 0 && total != expected))
                        throw new IOException("Modelo incompleto: " + total + " bytes");
                    verifyQwenChecksum(tmp);
                    neuralEngine.closeForModelReplacement();
                    replaceModelSafely(tmp, dest);
                    notifyNeuralImport("Modelo Qwen3-0.6B instalado (" + (total / 1048576) + " MiB). Prueba una pregunta para verificar que el motor puede cargarlo.");
                } catch (Exception e) {
                    tmp.delete();
                    notifyNeuralImport("No se pudo descargar el modelo: " + e.getMessage() + ". También puedes importarlo desde un archivo .litertlm.");
                } finally { if (conn != null) conn.disconnect(); }
            });
        }
        @JavascriptInterface public void importModel() {
            runOnUiThread(() -> {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.setType("*/*");
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(pick, REQ_NEURAL_MODEL);
            });
        }
        @JavascriptInterface public void ask(String question, String requestId) {
            if (question == null || question.trim().isEmpty() || question.length() > 3000) {
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.eaiNeuralReply(" + JSONObject.quote(requestId) + ",\"Consulta vacía o demasiado larga (máximo 3000 caracteres).\",false)", null); });
                return;
            }
            if (ElectricalSafety.isEmergency(question)) {
                String safe = ElectricalSafety.emergencyAnswer();
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.eaiNeuralReply(" + JSONObject.quote(requestId) + "," + JSONObject.quote(safe) + ",false,\"safety\")", null); });
                return;
            }
            neuralEngine.ask(question, (answer, ok) -> {
                try {
                    String js = "window.eaiNeuralReply(" + JSONObject.quote(requestId) + "," + JSONObject.quote(answer) + "," + ok + ")";
                    runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
                } catch (Exception ignored) { }
                return kotlin.Unit.INSTANCE;
            });
        }
    }
    /** Preserve last working model if replacement fails. Must be called after closing inference. */
    private static void replaceModelSafely(File incoming, File installed) throws IOException {
        File backup = new File(installed.getParentFile(), installed.getName() + ".backup");
        if (backup.exists() && !backup.delete()) throw new IOException("No se pudo limpiar respaldo antiguo");
        boolean hadModel = installed.exists();
        if (hadModel && !installed.renameTo(backup)) throw new IOException("No se pudo respaldar modelo existente");
        if (!incoming.renameTo(installed)) {
            if (hadModel && !backup.renameTo(installed)) throw new IOException("ERROR: modelo anterior conservado en " + backup.getAbsolutePath());
            throw new IOException("No se pudo activar el nuevo modelo; se restauró el anterior");
        }
        if (hadModel && !backup.delete()) android.util.Log.w("NeuralModel", "Respaldo pendiente de limpieza");
    }
    /** Pinned SHA-256 supplied in V6.10; provenance must be rechecked against the model repository for Qwen3-0.6B.litertlm. */
    private static void verifyQwenChecksum(File file) throws IOException {
        ModelIntegrity.verify(file);
    }
    private void notifyNeuralImport(String message) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.eaiNeuralStatus(" + JSONObject.quote(message) + ")", null); });
    }
    @Override protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AndroidFiles");
            web.destroy();
        }
        ioExecutor.shutdown();
        if (neuralEngine != null) neuralEngine.close();
        super.onDestroy();
    }
}
