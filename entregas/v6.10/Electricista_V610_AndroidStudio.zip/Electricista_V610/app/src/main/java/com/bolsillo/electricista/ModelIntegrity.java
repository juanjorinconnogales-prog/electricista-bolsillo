package com.bolsillo.electricista;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/** Qwen3 artifact identity pinned to metadata supplied with the project and by its owner. */
public final class ModelIntegrity {
    private ModelIntegrity() {}
    public static final long EXPECTED_BYTES = 613722264L;
    public static final String EXPECTED_SHA256 = "c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108";
    public static boolean hasExpectedSize(File file) {
        return file != null && file.isFile() && file.length() == EXPECTED_BYTES;
    }
    /** Call on the worker, never on the Android UI thread. Does not establish inference. */
    public static String verify(File file) throws IOException {
        if (!hasExpectedSize(file)) throw new IOException("Tamaño de modelo incorrecto: se requieren exactamente "
            + EXPECTED_BYTES + " bytes; recibidos " + (file == null ? 0 : file.length()));
        final MessageDigest digest;
        try { digest = MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException error) { throw new IOException("SHA-256 no disponible", error); }
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024]; int count;
            while ((count = input.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        StringBuilder hex = new StringBuilder();
        for (byte value : digest.digest()) hex.append(String.format(Locale.ROOT,"%02x",value & 255));
        if (!EXPECTED_SHA256.equals(hex.toString())) throw new IOException("SHA-256 del modelo incorrecto; se conserva el modelo anterior.");
        return hex.toString();
    }
}
