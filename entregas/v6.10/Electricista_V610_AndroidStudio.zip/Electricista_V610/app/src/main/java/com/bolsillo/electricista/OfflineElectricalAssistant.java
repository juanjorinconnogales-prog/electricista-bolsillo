package com.bolsillo.electricista;
import java.text.Normalizer;
import java.util.Locale;
/** Deterministic, fully offline knowledge assistant. Not a neural language model. */
public final class OfflineElectricalAssistant {
 private OfflineElectricalAssistant() {}
 public static String answer(String input) {
  if(input==null || input.trim().isEmpty()) return "Escribe una consulta sobre averías, protecciones o instalaciones.";
  if(ElectricalSafety.isEmergency(input)) return ElectricalSafety.emergencyAnswer();
  String q=Normalizer.normalize(input.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}", "");
  if(q.contains("diferencial") || q.contains("fuga") || q.contains("salta el id")) return "Diferencial: identifica qué circuito provoca el disparo, comprueba derivaciones y aislamiento con instrumentación adecuada. No puentear ni anular la protección. Si hay riesgo, desconecta y solicita personal habilitado.";
  if(q.contains("magnetotermico") || q.contains("automatico") || q.contains("sobrecarga")) return "Magnetotérmico: distingue sobrecarga de cortocircuito; revisa consumos, conexiones y sección, sin aumentar el calibre sin verificar el diseño y la protección del conductor.";
  if(q.contains("caida de tension")) return "Caída de tensión: introduce longitud, sección, material, intensidad y tipo de suministro en la calculadora. Verifica los límites aplicables del REBT y las condiciones de instalación.";
  if(q.contains("unifilar") || q.contains("esquema")) return "Unifilar: crea componentes en el editor y confirma manualmente cada conexión. Una foto frontal del cuadro NO permite deducir el cableado oculto ni certificar el circuito.";
  if(q.contains("contactor") && (q.contains("que es") || q.contains("para que") || q.contains("explica"))) return "Un contactor conecta y desconecta cargas mediante una bobina de mando (A1/A2) y contactos principales y auxiliares NA/NC. Se usa en motores, alumbrado y automatismos. No sustituye a las protecciones contra sobrecargas o cortocircuitos. Selecciona tensión de bobina y categoría de empleo según fabricante; no manipules bajo tensión.";
  if(q.contains("contactor") || q.contains("bobina")) return "Contactor: comprueba tensión nominal de bobina, circuito de mando, enclavamientos y estado de contactos. Aísla y verifica ausencia de tensión antes de intervenir.";
  if(q.contains("tierra") || q.contains("puesta a tierra")) return "Puesta a tierra: verifica continuidad del conductor de protección y medidas reglamentarias con equipo adecuado; una fotografía no demuestra su eficacia.";
  if(q.contains("no hay luz") || q.contains("sin tension") || q.contains("no funciona")) return "Avería sin suministro: revisa de forma segura el alcance de la incidencia, estado de protecciones y alimentación. Nunca manipules partes activas; verifica ausencia de tensión con equipo apropiado.";
  return "Consulta no cubierta por la biblioteca offline. Puedo orientar sobre diferenciales, magnetotérmicos, contactores, caída de tensión, tierra, averías y unifilares. No inventaré diagnósticos ni conexiones.";
 }
}
