package com.bolsillo.electricista;
import org.junit.Test;
import static org.junit.Assert.*;
public class ElectricalSafetyTest {
 @Test public void emergenciesOverrideTopicKeywords() {
  for(String q:new String[]{"humo en cuadro", "diferencial con chispas", "electrocución", "me da calambre", "fuego en contactor", "sparks in panel", "electric shock", "fumée au tableau", "étincelles", "choc électrique"}) {
   assertTrue(q, ElectricalSafety.isEmergency(q));
   assertTrue(q, OfflineElectricalAssistant.answer(q).contains("112"));
  }
 }
 @Test public void ordinaryQuestionsStayOrdinary() {
  for(String q:new String[]{"qué es un contactor", "caída de tensión", "diferencial tipo A", "puesta a tierra"}) assertFalse(q,ElectricalSafety.isEmergency(q));
 }
 @Test public void contactorDefinitionAndUnknownAreHonest() {
  assertTrue(OfflineElectricalAssistant.answer("qué es un contactor").contains("bobina"));
  assertTrue(OfflineElectricalAssistant.answer("xyz desconocido").contains("no cubierta"));
 }
 @Test public void outputValidationRejectsEmptyAndUnsafeAdvice() {
  assertTrue(ElectricalSafety.rejectsGeneratedAdvice(""));
  assertTrue(ElectricalSafety.rejectsGeneratedAdvice("puentea el diferencial"));
  assertFalse(ElectricalSafety.rejectsGeneratedAdvice("No anules protecciones. Consulta a un profesional."));
 }
}
