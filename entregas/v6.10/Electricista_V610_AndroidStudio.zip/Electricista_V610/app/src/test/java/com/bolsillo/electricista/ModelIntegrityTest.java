package com.bolsillo.electricista;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import org.junit.Test;
import static org.junit.Assert.*;
public class ModelIntegrityTest {
 @Test public void missingAndIncompleteFilesAreRejectedBeforeLoading() throws Exception {
  assertFalse(ModelIntegrity.hasExpectedSize(null));
  File incomplete=Files.createTempFile("incomplete-import-", ".bin").toFile();
  try {
   Files.write(incomplete.toPath(),new byte[]{1,2,3});
   assertFalse(ModelIntegrity.hasExpectedSize(incomplete));
   try {ModelIntegrity.verify(incomplete);fail("Incomplete input was accepted");}
   catch(IOException expected){assertTrue(expected.getMessage().contains("613722264"));}
  } finally {Files.deleteIfExists(incomplete.toPath());}
 }
}
