#!/usr/bin/env python3
"""Download the pinned V6.10 artifact atomically. Presence is not inference evidence.
The exact size and pinned SHA were confirmed by the user; see MODEL_MANIFEST.json for provenance limits.
"""
from pathlib import Path
import hashlib, urllib.request, sys, os, json, argparse, shutil
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'neuralmodel/src/main/assets/Qwen3-0.6B.litertlm'
URL='https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm'
SHA256='c5f39b4191926786c3e6668b62af4d6eb15248dfc7a5348252a9b406f33f2108'
EXPECTED_BYTES=613722264
MAX=EXPECTED_BYTES

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def verify(p):
    n=p.stat().st_size
    if n!=EXPECTED_BYTES:raise ValueError(f'Tamaño incorrecto: {n}; se requieren exactamente {EXPECTED_BYTES} bytes')
    actual=digest(p)
    if actual!=SHA256:raise ValueError(f'SHA256 no coincide: {actual}')
    return {'bytes':n,'sha256':actual,'url':URL,'inference_verified':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--from-file',type=Path,help='Importar pesos locales auténticos sin descargar')
    args=parser.parse_args()
    DEST.parent.mkdir(parents=True,exist_ok=True)
    part=DEST.with_suffix('.litertlm.part')
    try:
        if args.from_file is not None:
            evidence=verify(args.from_file)
            if args.from_file.resolve()!=DEST.resolve():
                shutil.copyfile(args.from_file,part)
                verify(part)
                os.replace(part,DEST)
            (ROOT/'evidence').mkdir(exist_ok=True)
            (ROOT/'evidence/model-local-import.json').write_text(json.dumps(evidence,indent=2))
            print(json.dumps(evidence,indent=2));return 0
        if DEST.exists():
            print(json.dumps(verify(DEST),indent=2));return 0
        print('Descargando pesos reales desde',URL,flush=True)
        request=urllib.request.Request(URL,headers={'User-Agent':'ElectricistaBolsilloModelInstaller/6.10'})
        with urllib.request.urlopen(request,timeout=90) as response,part.open('wb') as out:
            while True:
                chunk=response.read(1024*1024)
                if not chunk:break
                out.write(chunk)
                if out.tell()>MAX:raise ValueError('Descarga excede el límite')
        evidence=verify(part)
        os.replace(part,DEST)
        (ROOT/'evidence').mkdir(exist_ok=True)
        (ROOT/'evidence/model-download.json').write_text(json.dumps(evidence,indent=2))
        print(json.dumps(evidence,indent=2));return 0
    except Exception as e:
        print('BLOQUEADO: no se ha instalado ni validado el modelo:',e,file=sys.stderr)
        if part.exists():part.unlink()
        return 1
if __name__=='__main__':sys.exit(main())
