# Dependencias y licencias

- LiteRT-LM Android 0.18.0: Apache-2.0. Se adjuntan LICENSE y THIRD_PARTY_NOTICE del AAR descargado de dl.google.com. Código/API cotejados con google-ai-edge/LiteRT-LM, tag v0.18.0.
- Qwen3-0.6B: la documentación oficial QwenLM/Qwen3 declara Apache-2.0 para sus modelos abiertos. Los pesos convertidos .litertlm NO se han descargado. Debe confirmarse también licencia y procedencia de esa conversión antes de redistribuir. No se adjuntan pesos ni se atribuye una licencia comprobada a un archivo ausente.
- Bootstrap 5.3.6: MIT; aviso conservado en el HTML.
- PDF.js: Apache-2.0; licencia original recibida en PDFJS-LICENSE.txt y avisos de copyright conservados en los módulos. Se redistribuyen módulos originales y transformación de sintaxis con esbuild, sin cambiar el parser deliberadamente.
- core-js 3.45.1: MIT; CORE-JS-LICENSE.txt. Polyfills incluidos en el HTML, sin CDN.
- esbuild 0.25.11: MIT; ESBUILD-LICENSE.md. Herramienta de compilación, no motor neuronal.
- Gradle Wrapper 8.13: Apache-2.0; licencia recibida en gradle/wrapper/LICENSE-Gradle.txt.
- AndroidX Core 1.16.0, Activity 1.10.1, WebKit 1.14.0, SwipeRefreshLayout 1.1.0 y test runner 1.6.2 / ext JUnit 1.2.1: Apache-2.0.
- Kotlin y kotlinx-coroutines-core 1.10.2: Apache-2.0.
- Google ML Kit text-recognition 16.0.1, object-detection 17.0.2 y object-detection-custom 17.0.2, Google Play Asset Delivery 2.3.0: dependencias Google sujetas a sus condiciones y avisos propios. No se presentan como código abierto íntegro. El runtime neuronal LiteRT-LM sí es abierto.
- JUnit 4.13.2: EPL-1.0; solo pruebas.
- Playwright 1.57.0 y adb-shell 0.4.4: Apache-2.0; solo herramientas de prueba. No se empaquetan en la aplicación.

No se añaden licencias a textos/precios originales que no las tuvieran. El catálogo mantiene su procedencia y sus etiquetas de referencia consultada, estimación o precio pendiente. Este manifiesto no sustituye la revisión de las licencias transitivas exigida para publicar.
