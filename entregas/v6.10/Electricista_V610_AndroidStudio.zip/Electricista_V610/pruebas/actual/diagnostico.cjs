const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'../../app/src/main/assets/index.html'),'utf8');
const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].filter(x=>!x[0].startsWith('<script type="module"')).map(x=>x[1]);
scripts.forEach((s,i)=>new vm.Script(s,{filename:'inline-'+i+'.js'}));
const start=html.indexOf('const KB = ['),end=html.indexOf('// Expuesta únicamente',start);
const ctx={window:{},document:{addEventListener(){}},nrm:s=>String(s??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')};vm.createContext(ctx);vm.runInContext(html.slice(start,end),ctx);
const tests=[
 ['lavadora no enciende pero enchufe tiene corriente','aparato_alimentado'],
 ['motor trifásico no arranca, guardamotor no ha saltado y hay tensión en las tres fases','motor_tri_mando'],
 ['motor trifásico no arranca y salta el guardamotor','guardamotor'],
 ['lavadora salta diferencial al calentar','lavadora'],
 ['lavadora no enciende, el diferencial no ha saltado, enchufe con tensión','aparato_alimentado'],
 ['enchufe no tiene tensión','enchufe'],['enchufe sin corriente','enchufe'],
 ['no hay humo pero hay chispas','quemado'],['no hay chispas pero hay humo','quemado'],
 ['diferencial no salta y magnetotérmico salta','magnetotermico'],
 ['el diferencial salta y el magnetotérmico no salta','diferencial'],
 ['lavadora no arranca','lavado_sin_inicio'],
 ['washing machine does not turn on but socket has power','aparato_alimentado'],
 ['lave-linge ne s’allume pas mais la prise a de la tension','aparato_alimentado'],
 ['three-phase motor does not start, motor breaker has not tripped and there is voltage on all three phases','motor_tri_mando'],
 ['moteur triphasé ne démarre pas, disjoncteur moteur n’a pas déclenché et il y a de la tension sur les trois phases','motor_tri_mando'],
 ['diferencial no salta pero diferencial salta','datos_inciertos'],
 ['lavadora no desagua','lavado_desague'],['motor gira al reves','motor_sentido'],
 ['inversor aislamiento','fv_aislamiento'],['plc entrada','plc_entrada'],['coche no carga','ve_bloqueo'],
 ['horno y microondas al mismo tiempo salta magnetotermico 16 A','cocina_carga'],
 ['texto desconocido sin equipo',null],['',null]
];
tests.push(['no hay humo ni chispas',null],['lavadora enchufe tiene corriente','datos_inciertos']);
tests.push(['prise n’a pas de tension','enchufe'],['il n’y a pas de tension dans la prise','enchufe'],['socket has no power','enchufe'],['diferencial no ha disparado y lavadora no enciende pero enchufe tiene corriente','aparato_alimentado']);
const results=tests.map(([q,id])=>{const d=ctx.window.diagnosticoLocalV43(q),actual=d?.principal.id||null;return {q,expected:id,actual,pass:id===actual,ctx:d?.ctx};});
for(const [device,field] of [['diferencial','diferencial'],['guardamotor','guardamotorEstado'],['magnetotermico','termicoEstado']]){
 for(const verb of ['no salta','no ha saltado','no dispara','no se dispara','nunca salta','tampoco dispara','sin disparo']){const q=device+' '+verb;const d=ctx.window.diagnosticoLocalV43(q);results.push({q,expected:'negado',actual:d?.ctx[field],pass:d?.ctx[field]==='negado'});}
 for(const verb of ['salta','ha saltado','dispara','se dispara','disparo']){const q=device+' '+verb;const d=ctx.window.diagnosticoLocalV43(q);results.push({q,expected:'presente',actual:d?.ctx[field],pass:d?.ctx[field]==='presente'});}
}
for(const item of ctx.window.bibliotecaV43){assert(item.id&&item.titulo&&item.causas&&item.preguntas&&item.comprob);assert.equal(item.materiales.length,0);if(item.v43){assert.equal(item.v43.length,3);for(const row of item.v43)assert(row.length===4&&row.every(Boolean));}}
for(const x of results)console.log((x.pass?'PASS':'FAIL')+' '+x.q+' => '+x.actual);
fs.writeFileSync(require('path').join(__dirname,'legacy-engine.json'),JSON.stringify(results,null,2));
assert(results.every(x=>x.pass),'Diagnosis regression failure');
console.log('Syntax: '+scripts.length+' scripts; catalogue: '+ctx.window.bibliotecaV43.length+' entries; cases: '+results.length);
