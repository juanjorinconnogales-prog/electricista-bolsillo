const fs=require('fs'),vm=require('vm'),assert=require('assert');
const h=fs.readFileSync(require('path').join(__dirname,'../../app/src/main/assets/index.html'),'utf8'),ctx={window:{},document:{addEventListener(){}},nrm:s=>String(s??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')};vm.createContext(ctx);vm.runInContext(h.slice(h.indexOf('const KB = ['),h.indexOf('// Expuesta únicamente')),ctx);
const cases=[
 ['La lavadora enciende bloquea la puerta y carga agua pero el tambor no gira ni salta ninguna protección','lavado_giro',{encendido:'presente',puerta:'presente',entrada:'presente',giro:'negado'}],
 ['La lavadora enciende, bloquea la puerta y carga agua, pero el tambor no gira. No salta ninguna protección.','lavado_giro',{giro:'negado'}],
 ['lavadora no gira','lavado_giro',{giro:'negado'}],
 ['lavadora no centrifuga','lavado_giro',{centrifugado:'negado'}],
 ['lavadora enciende pero no coge agua','lavado_entrada',{encendido:'presente',entrada:'negado'}],
 ['lavadora enciende pero no bloquea la puerta','lavado_sin_inicio',{encendido:'presente',puerta:'negado'}],
 ['lavadora carga agua pero no desagua','lavado_desague',{entrada:'presente',desague:'negado'}],
 ['lavadora enciende pero no calienta','lavado_calor',{encendido:'presente',calor:'negado'}],
 ['lavadora enciende y gira pero no centrifuga','lavado_giro',{encendido:'presente',giro:'presente',centrifugado:'negado'}],
 ['lavadora enciende y no enciende','datos_inciertos',{encendido:'contradictorio'}],
 ['washing machine turns on, door locks, fills with water but drum does not rotate','lavado_giro',{puerta:'presente',entrada:'presente',giro:'negado'}],
 ['lave-linge allume, verrouille la porte et prend de l’eau mais le tambour ne tourne pas','lavado_giro',{puerta:'presente',entrada:'presente',giro:'negado'}]
];
const results=[];
for(const [q,id,facts] of cases){const d=ctx.window.diagnosticoLocalV43(q);assert.equal(d.principal.id,id,q);for(const [key,v] of Object.entries(facts))assert.equal(d.ctx.etapas[key],v,q);if(facts.encendido==='presente')assert(!d.preguntas.includes('¿Enciende la pantalla?'));if(facts.puerta==='presente')assert(!d.preguntas.includes('¿Bloquea la puerta?'));if(facts.entrada==='presente')assert(!d.preguntas.includes('¿Entra agua?'));if(id==='lavado_giro')assert(!/calefactor|resistencia|calentamiento|heater/.test(d.causas));if(q.includes('ni salta ninguna'))assert.equal(d.ctx.protecciones,'negado');results.push({q,id,ctx:d.ctx,causes:d.causas,questions:d.preguntas,pass:true});}
fs.writeFileSync(require('path').join(__dirname,'legacy-stages.json'),JSON.stringify(results,null,2));console.log(results.length+' phase and question regression tests PASS');
