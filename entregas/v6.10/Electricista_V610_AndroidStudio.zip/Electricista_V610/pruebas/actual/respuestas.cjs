const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(require('path').join(__dirname,'../../app/src/main/assets/index.html'),'utf8');
const ctx={window:{},document:{addEventListener(){}},nrm:s=>String(s??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')};vm.createContext(ctx);vm.runInContext(html.slice(html.indexOf('const KB = ['),html.indexOf('// Expuesta únicamente')),ctx);
const checks=[];
for(const q of [
 'salta el diferencial al poner la lavadora, no pierde agua y no llega a calentar',
 'Salta el diferencial al poner la lavadora no pierde agua y no llega a calentar',
 'salta el diferencial al poner la lavadora. Sin fuga de agua. No calienta.',
 'washing machine trips the RCD, no water leak and does not heat',
 'lave-linge déclenche le différentiel, sans fuite d’eau et ne chauffe pas'
]){
 const d=ctx.window.diagnosticoLocalV43(q);assert.equal(d.principal.id,'lavadora');assert.equal(d.ctx.calor,'negado');assert.equal(d.ctx.agua,'negado');assert(!/si dispara al calentar/i.test(d.causas));assert(!/coincide con el calentamiento|pierde agua|llega a calentar/i.test(d.preguntas));
 for(const [lang,row] of d.localized.entries()){assert(!/coincide con el calentamiento|visible water leak\?|fuite d’eau visible \?/i.test(row[2]));checks.push({q,language:lang,causes:row[1],questions:row[2],pass:true});}
 assert(d.extra.includes('Disparo del diferencial: presente'));
}
for(const q of ['No hay humo ni chispas el enchufe ni tiene tensión','No hay humo ni chispas. El enchufe no tiene tensión.','No hay humo ni chispas, el enchufe no tiene tensión','el enchufe ni tiene corriente','el enchufe no tiene tensión']){const d=ctx.window.diagnosticoLocalV43(q);assert.equal(d.principal.id,'enchufe',q);assert.equal(d.ctx.tension,'negado',q);assert.equal(d.ctx.peligro,false,q);checks.push({q,pass:true});}
// Both affirmative and unknown symptoms still produce appropriate follow-up questions.
let d=ctx.window.diagnosticoLocalV43('salta el diferencial al poner la lavadora');assert(d.preguntas.includes('¿Hay fuga de agua visible?'));assert(d.preguntas.includes('¿Llega a calentar antes del disparo?'));checks.push({q:d.pregunta,pass:true});
d=ctx.window.diagnosticoLocalV43('lavadora salta el diferencial al calentar y pierde agua');assert.equal(d.ctx.calor,'presente');assert.equal(d.ctx.agua,'presente');assert(d.causas.includes('durante el calentamiento'));assert(!d.preguntas.includes('¿Hay fuga de agua visible?'));checks.push({q:d.pregunta,pass:true});
fs.writeFileSync(require('path').join(__dirname,'legacy-responses.json'),JSON.stringify(checks,null,2));console.log(checks.length+' complete-response checks PASS');
