const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE||undefined,args:['--no-sandbox','--disable-dev-shm-usage']});
 const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
 const page=await context.newPage(),errors=[],checks=[],requests=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:8765/')&&/^https?:/.test(r.url()))requests.push(r.url())});page.on('dialog',d=>d.accept());
 await page.goto('http://127.0.0.1:8765/app/src/main/assets/index.html');
 await context.setOffline(true);checks.push('Browser network disabled after loading all-local HTML');
 await page.locator('#eai-toggle').click();assert(await page.locator('#eai-panel').isVisible());
 assert.equal(await page.locator('#eai-toggle').evaluate(e=>getComputedStyle(e).position),'static');
 await page.locator('#eai-close').click();await page.locator('#nav-asistente').click();assert(await page.locator('#eai-panel').isVisible());checks.push('Header blue assistant and bottom assistant both open panel; header stays in document flow');
 const emergencies=['humo en cuadro','diferencial con chispas','electrocución','me da calambre','fuego en contactor','sparks in panel','electric shock','fumée au tableau','étincelles','choc électrique','chispa en bobina'];
 for(const q of emergencies){
  await page.locator('#eai-question').fill(q);await page.locator('#eai-send').click();const text=await page.locator('#eai-output').innerText();
  assert(text.includes('112'),q+': '+text);assert(!text.includes('IA neuronal local:'),q);
 }
 checks.push(`${emergencies.length} ES/EN/FR emergencies use safety rules without neural attribution`);
 await page.locator('#eai-question').fill('qué es un contactor');await page.locator('#eai-send').click();let text=await page.locator('#eai-output').innerText();assert(text.includes('bobina'));assert(text.includes('Motor de reglas'));checks.push('Contactor definition and explicit rules-only state without Android bridge');
 await page.locator('#eai-cancel').click();assert.equal(await page.locator('#eai-output').innerText(),'Consulta cancelada.');await page.locator('#eai-close').click();
 const calc=await page.evaluate(()=>{
  const mono=calculoElectricoV50(2.3,10,'monofasico',1,3,'cu',20,0,1);
  const tri=calculoElectricoV50(6.928203230275509,10,'trifasico',1,3,'cu',20,0,1);
  const errors=[];for(const args of [[0,10,'monofasico',1,3,'cu',20,0,1],[1,-10,'monofasico',1,3,'cu',20,0,1],[1,10,'monofasico',0,3,'cu',20,0,1],[1,10,'monofasico',1,3,'xx',20,0,1],[1,10,'unknown',1,3,'cu',20,0,1]]){try{calculoElectricoV50(...args);errors.push(false)}catch{errors.push(true)}}
  return {mono,tri,errors};
 });
 assert(Math.abs(calc.mono.I-10)<1e-10);assert.equal(calc.mono.U,230);assert.equal(calc.mono.seccion,1.5);assert(Math.abs(calc.mono.caidaV-2.2988)<1e-8);assert(Math.abs(calc.tri.I-10)<1e-9);assert.equal(calc.tri.U,400);assert(calc.errors.every(Boolean));checks.push('Independent reference cases: single-phase 10 A / 2.2988 V drop, three-phase 10 A; five invalid inputs rejected');
 const diag=await page.evaluate(()=>['no hay humo pero hay chispas','no hay chispas pero hay humo','no hay humo ni chispas'].map(q=>diagnosticoLocalV43(q)?.principal.id||null));assert.deepEqual(diag,['quemado','quemado',null]);checks.push('Mixed positive/negative fire evidence and fully negated case');
 await page.screenshot({path:path.resolve('evidence/v610-mobile-offline.png'),fullPage:true});
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 fs.writeFileSync('evidence/v610-browser-results.json',JSON.stringify({checks,calc,errors,externalRequests:requests,neuralInferenceTested:false},null,2));console.log(JSON.stringify({checks,errors,externalRequests:requests},null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
