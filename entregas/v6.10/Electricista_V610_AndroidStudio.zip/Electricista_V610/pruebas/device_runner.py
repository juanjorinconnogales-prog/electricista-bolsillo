#!/usr/bin/env python3
"""Local emulator runner. Uses standard ADB protocol; no external service.
pip install adb-shell; Emulator default debuggable image must listen on localhost:5555.
"""
from adb_shell.adb_device import AdbDeviceTcp
from pathlib import Path
import time,json,hashlib,sys
root=Path(__file__).resolve().parent.parent
out=root/'evidence'
for connection_attempt in range(5):
 d=AdbDeviceTcp('127.0.0.1',5555,default_transport_timeout_s=60)
 try:d.connect(auth_timeout_s=60);break
 except Exception:
  d.close()
  if connection_attempt==4:raise
  print('Emulator transport not ready; retry',connection_attempt,flush=True);time.sleep(2)
print('Connected to local Android emulator',flush=True)
for attempt in range(60):
    if d.shell('getprop sys.boot_completed',timeout_s=90).strip()=='1':break
    if attempt%6==0:print('Waiting for Android boot, attempt',attempt,flush=True)
    time.sleep(5)
else:raise RuntimeError('Android did not finish boot in 300 seconds; no device tests passed')
if '--installed' not in sys.argv:
 for local,remote in [(root/'app/build/outputs/apk/debug/app-debug.apk','/data/local/tmp/v610.apk'),(root/'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk','/data/local/tmp/v610-test.apk')]:
  print('Pushing',local.name,flush=True);d.push(str(local),remote,read_timeout_s=300,transport_timeout_s=120)
  result=d.shell('pm install -r -t '+remote,timeout_s=900,read_timeout_s=900);print(result,flush=True)
  if 'Success' not in result:raise RuntimeError('APK installation failed')
print(d.shell('getprop sys.boot_completed; getprop ro.product.cpu.abi; getprop ro.build.version.release',timeout_s=90),flush=True)
# Explicitly disable connectivity inside the emulator before running actual offline tests.
print(d.shell('cmd connectivity airplane-mode enable; svc wifi disable; svc data disable',timeout_s=60),flush=True)
network=d.shell('settings get global airplane_mode_on; dumpsys connectivity',timeout_s=60)
(out/'device-offline-network.log').write_text(network);print(network[:14000],flush=True)
if 'Active default network: none' not in network:raise RuntimeError('Device is not offline')
d.shell('settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0; wm dismiss-keyguard; input keyevent 4',timeout_s=60)
d.shell('am force-stop com.juanjo.electricistabolsillov42.pruebas',timeout_s=90,transport_timeout_s=90)
result=d.shell('am instrument -w -r com.juanjo.electricistabolsillov42.pruebas.test/androidx.test.runner.AndroidJUnitRunner',timeout_s=600,read_timeout_s=600,transport_timeout_s=600)
(out/'instrumentation-results.log').write_text(result)
print(result,flush=True)
for filename in ['ocr-evidence.txt','webview-evidence.txt','neural-evidence.json']:
 text=d.shell('run-as com.juanjo.electricistabolsillov42.pruebas cat files/'+filename,timeout_s=90)
 print(filename+': '+text,flush=True)
 if 'No such file' not in text:(out/filename).write_text(text)
try:
 import base64
 text=d.shell('run-as com.juanjo.electricistabolsillov42.pruebas base64 files/webview-evidence.png',timeout_s=60)
 if 'No such file' not in text:(out/'android-webview-tested.png').write_bytes(base64.b64decode(text))
except Exception as error:print('No UI screenshot:',error,flush=True)
print(d.shell('am start -n com.juanjo.electricistabolsillov42.pruebas/com.bolsillo.electricista.MainActivity',timeout_s=60),flush=True)
(out/'device-logcat.log').write_text(d.shell('logcat -d -t 1500',timeout_s=60))
d.shell('screencap -p /data/local/tmp/v610.png',timeout_s=60)
d.pull('/data/local/tmp/v610.png',str(out/'android-screen.png'),read_timeout_s=60)
d.close()

if "FAILURES!!!" in result or "INSTRUMENTATION_FAILED" in result:sys.exit(1)
