#!/usr/bin/env python3
"""Reproducible local-browser suite; dependencies: Node, npm install, npx playwright install chromium."""
import subprocess,sys,time,urllib.request,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
E=ROOT/'evidence';E.mkdir(exist_ok=True)
server=None
try:
 try: urllib.request.urlopen('http://127.0.0.1:8765/app/src/main/assets/index.html',timeout=2).close()
 except Exception:
  server=subprocess.Popen([sys.executable,'-m','http.server','8765','--bind','127.0.0.1','--directory',str(ROOT)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  time.sleep(1)
 results=[]
 for name in ['diagnostico','etapas','vocabulario','respuestas','interfaz-v45','regresion-app-v45','v610-browser','v610-preservation']:
  result=subprocess.run(['node',str(ROOT/'pruebas/actual'/f'{name}.cjs')],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (E/f'{name}-reproducible.log').write_text(result.stdout)
  results.append({'test':name,'status':'PASS' if result.returncode==0 else 'FAIL','exit_code':result.returncode})
  print(results[-1],flush=True)
 (E/'web-suite-results.json').write_text(json.dumps(results,indent=2))
 sys.exit(0 if all(r['status']=='PASS' for r in results) else 1)
finally:
 if server:server.terminate();server.wait()
