#!/usr/bin/env python3
"""Fail closed: verified weights AND actual offline device inference evidence required."""
from pathlib import Path
import json,sys
from instalar_modelo_oficial import DEST,verify
root=Path(__file__).resolve().parent
try:
 weights=verify(DEST)
 evidence=json.loads((root/'evidence/neural-evidence.json').read_text())
 if not (evidence['status']=='PASS' and evidence['offline_network_check'] is True
  and evidence['model_sha256']==weights['sha256'] and len(evidence['output'].strip())>10):
  raise ValueError('La evidencia no demuestra inferencia offline con estos pesos')
 print('PASS: integridad y evidencia de inferencia. Revisar además informe de regresión y licencia del artefacto.')
except (OSError,ValueError,KeyError) as error:
 print('RELEASE BLOQUEADO:',error);sys.exit(2)
