// Rebuild bundled compatibility assets. npm install; node tools/build_webview_compat.cjs
const fs=require('fs'),path=require('path'),esbuild=require('esbuild');
const root=path.resolve(__dirname,'..'),source=path.join(root,'fuentes-web/index.html');let html=fs.readFileSync(source,'utf8');
const moduleMatches=[...html.matchAll(/<script type="module">([\s\S]*?)<\/script>/g)];
if(moduleMatches.length!==2)throw Error('Expected both original PDF.js modules');
for(const [i,match] of moduleMatches.entries()){
 const filename=path.join(root,'fuentes-web/vendor',i?'pdfjs-main.original.mjs':'pdfjs-worker.original.mjs');
 if(!fs.existsSync(filename))fs.writeFileSync(filename,match[1]);
 const original=fs.readFileSync(filename,'utf8');const license=original.match(/^\/\*\*[\s\S]*?\*\//)?.[0]||'';
 const transformed=esbuild.transformSync(original,{target:'chrome83',format:'esm',minify:true,legalComments:'inline'}).code;
 html=html.replace(match[0],()=>'<script type="module">'+license+'\n'+transformed+'</script>');
}
const bundled=esbuild.buildSync({stdin:{contents:"require('core-js/actual');",resolveDir:root},bundle:true,nodePaths:[path.dirname(path.dirname(require.resolve('core-js/package.json')))],write:false,minify:true,target:'chrome83',format:'iife',legalComments:'inline'}).outputFiles[0].text;
const dom=`\n// DOM Standard replaceChildren (Chrome 86+); app supports older Android WebViews.\nfor(const C of [Element,Document,DocumentFragment])if(!C.prototype.replaceChildren)Object.defineProperty(C.prototype,'replaceChildren',{configurable:true,writable:true,value:function(...nodes){while(this.firstChild)this.removeChild(this.firstChild);for(const node of nodes)this.appendChild(typeof node==='string'?this.ownerDocument.createTextNode(node):node);}});\n`;
html=html.replace(/<script id="webview-compat">[\s\S]*?<\/script>\s*/,'');
html=html.replace('</head>',()=>'<script id="webview-compat">'+bundled+dom+'</script>\n</head>');
if((html.match(/<!DOCTYPE html>/gi)||[]).length!==1||(html.match(/<script\b/g)||[]).length!==12)throw Error('HTML structure invariant failed');
fs.writeFileSync(source,html);fs.writeFileSync(path.join(root,'app/src/main/assets/index.html'),html);
console.log('Embedded official core-js polyfills and transpiled PDF.js for Chrome/WebView 83');
