#!/usr/bin/env python3
"""Package actual built artifacts, source and evidence. Never adds model weights implicitly."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=root/'output');args=parser.parse_args()
out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
for source,name in [
 ('fuentes-web/index.html','Electricista_V610.html'),
 ('app/build/outputs/apk/debug/app-debug.apk','Electricista_V610_debug_sin_pesos.apk'),
 ('app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk','Electricista_V610_pruebas_android.apk'),
 ('app/build/outputs/bundle/release/app-release.aab','Electricista_V610_release_sin_pesos_sin_firma.aab'),
 ('INFORME_PRUEBAS_V610.md','Informe_pruebas_V610.md')]:
 shutil.copy2(root/source,out/name)
exclude={'.git','.gradle','.kotlin','build','node_modules','__pycache__','output','tmp'}
source_zip=out/'Electricista_V610_AndroidStudio.zip'
with zipfile.ZipFile(source_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if rel==Path('evidence/packaging.log') or any(part in exclude for part in rel.parts) or p.suffix in {'.keystore','.jks'} or p==source_zip or out in p.parents:continue
  z.write(p,Path('Electricista_V610')/rel)
with zipfile.ZipFile(out/'Evidencias_V610.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted((root/'evidence').rglob('*')):
  if p.is_file() and p.name!='packaging.log':z.write(p,p.relative_to(root))
for p in [source_zip,out/'Evidencias_V610.zip']:
 with zipfile.ZipFile(p) as z:
  bad=z.testzip()
  if bad:raise RuntimeError('ZIP corrupto: '+bad)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file() and p.name not in {'SHA256SUMS.txt','ENTREGABLES.json'}}
(out/'SHA256SUMS.txt').write_text(''.join(v['sha256']+'  '+k+'\n' for k,v in manifest.items()))
(out/'ENTREGABLES.json').write_text(json.dumps({'files':manifest,'release_ready':False,'neural_inference_verified':False,'note':'Pesos ausentes; APK debug instalable, AAB sin firma de publicación. Ver informe.'},indent=2))
print(json.dumps(manifest,indent=2))
