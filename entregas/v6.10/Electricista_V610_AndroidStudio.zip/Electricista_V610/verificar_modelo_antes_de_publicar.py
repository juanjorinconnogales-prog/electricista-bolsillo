#!/usr/bin/env python3
"""Offline preflight; exact bytes and SHA do not prove inference."""
import sys
from instalar_modelo_oficial import DEST,verify
try: print(verify(DEST));print('Pesos íntegros según pin. Ejecutar prueba de inferencia real antes de publicar.')
except (OSError,ValueError) as error:print('BLOQUEADO:',error);sys.exit(2)
